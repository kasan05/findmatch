package com.spboot.testspboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestspbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
