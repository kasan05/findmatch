package com.spboot.testspboot.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class TestController {

    @GetMapping("/")
    public ResponseEntity<String> welcome(){
        return new ResponseEntity<>("Welcome",HttpStatus.OK);
    }
    @GetMapping("/aws/ecs")
    public ResponseEntity<String> test(){
        return new ResponseEntity<>("AWS ECS is working", HttpStatus.OK);
    }
}
