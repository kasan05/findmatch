import { createTheme } from "@mui/material";

const theme = createTheme({
    components:{
        MuiTypography:{
            styleOverrides:{
              root:{
                fontFamily:"'Montserrat', sans-serif"
              }
            }
          }
    },
    palette: {
        primary: {
            main:'#ADD8E6'
        },
        secondary:{
            main:'#ADD8E6'
        }
    },
    typography:{
        fontFamily:["Montserrat", "sans-serif"].join(",")
    }
})

export default theme;