import { createSlice } from "@reduxjs/toolkit";
import type { Country } from "../types/SelectedCountry";

type CountryState = {
    countries:Country[]
    selectedCountries:Country[]
}
const initialState:CountryState = {
   countries:[],
   selectedCountries:[]
}

const CountrySlice = createSlice({
    name:"countries",
    initialState:initialState, 
    reducers:{
        loadCountries : (state,action)=>{
            state.countries = action.payload
        },
        onCheckCountryValue :(state,action)=>{
            state.selectedCountries = action.payload
        }
    }

})

export const {loadCountries,onCheckCountryValue} = CountrySlice.actions
export default CountrySlice.reducer