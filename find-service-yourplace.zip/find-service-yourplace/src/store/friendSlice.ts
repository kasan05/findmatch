import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { MatchMakerSearchProfile } from "../types/MatchMakerSearchProfile";
import type { FriendRequest } from "../components/Registration/types/FriendRequest";

type FriendState ={
    friends:Array<MatchMakerSearchProfile>
    loading:boolean
}
const initialState : FriendState= {
    friends : [],
    loading:false
}
export const loadFriends = createAsyncThunk("friend/list",async (a,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/friend',{
        method:"GET",
       credentials:'include'
   }).then(res=>{
       if(res.status!=200){
           return rejectWithValue("Internal Server Error");
       }else{
           return res.json();
       }
   }).catch(e=>{
       if(!e.response){
           return rejectWithValue("Internal Server Error");
       }
       return rejectWithValue(e.response.data.message);
   })

})

export const loadFriendRequest = createAsyncThunk("friend/request",async (a,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/friend/req/sender',{
         method:"GET",
        credentials:'include'
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})
export const respondToFriendRequest = createAsyncThunk("",async(friendRequestDTO:FriendRequest,{rejectWithValue})=>{
    
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/friend/req/respond',{
        method:"PUT",
        headers:{
            'Content-Type': 'application/json'
        },
        body:JSON.stringify(friendRequestDTO),
       credentials:'include'
   }).then(res=>{
       if(res.status!=200){
           return rejectWithValue("Internal Server Error");
       }else{
           return res.json();
       }
   }).catch(e=>{
       if(!e.response){
           return rejectWithValue("Internal Server Error");
       }
       return rejectWithValue(e.response.data.message);
   })
})
const FriendSlice = createSlice({
    name:"friends",
    initialState:initialState,
    reducers:{},
    extraReducers(builder) {
         builder.addCase(loadFriendRequest.pending,(state,payload)=>{
            state.loading = true
         }).addCase(loadFriendRequest.fulfilled,(state,payload)=>{
            state.loading = false
            state.friends = payload?.payload
         }).addCase(loadFriendRequest.rejected,(state,payload)=>{
            state.loading = false
         }).addCase(respondToFriendRequest.pending,(state,payload)=>{
            state.loading = true
         }).addCase(respondToFriendRequest.fulfilled,(state,payload)=>{
            state.loading = false 
         }).addCase(respondToFriendRequest.rejected,(state,payload)=>{
            state.loading = false
         }).addCase(loadFriends.pending,(state,payload)=>{
            state.loading = true
         }).addCase(loadFriends.fulfilled,(state,payload)=>{
            state.loading = false
            state.friends = payload?.payload
         }).addCase(loadFriends.rejected,(state,payload)=>{
            state.loading = false
         })
    }
})

export default FriendSlice.reducer;