import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import type { UserDto } from "../types/UserDto";
import type User from "../types/User";
export const createBrokerAsync = createAsyncThunk("broker/create",async (userObj:FormData,{rejectWithValue})=>{

    console.log(userObj);
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/api/user',{
        method:"POST",
        body:userObj,
        credentials: 'include'
    }).then(res=>{
        if(res.status!=201){
            if(res.status==409)
              return rejectWithValue("Email has been used before");
            else
              return rejectWithValue("Internal Server Error");
        }
        return res.json()
    })
        .then(data=>data)
        .catch(e=>{
            console.log(e);
            if(!e.response){
                return rejectWithValue('Server is Down');
            }
            return rejectWithValue(e.response.data.message);
        })
})
export const loginAsync = createAsyncThunk("broker/login",async (userDto:UserDto,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/auth/login',{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(userDto),
        credentials: 'include'
    })
    .then(res=>{
        const status = res.status;
        if(status!=200){
            if(status==403){
                return rejectWithValue('Account has not been activated yet');
            }else if(status==404){
                return rejectWithValue('Account is Not Found');
            }else{
                return rejectWithValue('Internal server error');
            }
        }

        return res.json()
    })
    .then(data=>data)
    .catch(e=>{
        if(!e.response){
            return rejectWithValue('Server is Down');
        }
        console.log(e);
        return rejectWithValue(e.response.data.message || 'Login failed');
    })
})

export const getProfile = createAsyncThunk("user/profile",async ()=>{

    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/user/profile',{
        method:"GET",
        headers:{"Content-Type":"application/json"},
        credentials: 'include'
    }) .then(res=>{
        if(res.status!=200){

        }
        return res.json()
    })
    .then(data=>data)
})

export const logoutUser = createAsyncThunk("user/logout",async (a,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/auth/logout',{
        method:"GET",
        credentials: 'include'
    }).then(res=>res.json())
    .catch(e=>{
        if(!e.response){
             return rejectWithValue('Internal server error');
        }
        console.log(e);
        return rejectWithValue(e.response.data.message || 'Login failed');
    })
})

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

type BrokerState ={
    broker:Object
    user:User |undefined ,
    loading:boolean,
    submissionSuccessState:boolean,
    loginPageLoading:boolean,
    errorMessage:string
    isAutheticated:boolean,
    isAutheticatedPending:boolean,
    errorMessageRegistration:string
}
const initialState:BrokerState={
    broker:{},
        user:undefined ,
        loading:false,
        submissionSuccessState:false,
        loginPageLoading:false,
        errorMessage:"",
        isAutheticated:false,
        isAutheticatedPending:false,
        errorMessageRegistration:""
}
const BrokerSlice = createSlice({
    name:"broker",
    initialState:initialState,
    reducers:{
        updateAuthState:(state,payload)=>{
            state.isAutheticated = true;
            state.user = {
                id:payload.payload.id,
                name:payload.payload.name,
                token:payload.payload.token,
                userStatus:payload.payload?.userStatus
            }
        },
        resetState:(state,payload)=>{
            console.log("dd")
            state.loading = false;
            state.submissionSuccessState=false;
            state.isAutheticated = false
            state.errorMessageRegistration = ""
        }
    },
   extraReducers(builder) {
       builder.addCase(createBrokerAsync.pending,(state,payload)=>{
            state.loading = true;
       })
       .addCase(createBrokerAsync.fulfilled,(state,payload)=>{
        state.loading = false;
        state.submissionSuccessState=true;
        }).addCase(createBrokerAsync.rejected,(state,payload)=>{
            state.loading = false;
            state.submissionSuccessState=false;
            state.isAutheticated = false
            state.errorMessageRegistration = ""
        })
        .addCase(loginAsync.pending,(state,payload)=>{
            state.loginPageLoading = true
        })
        .addCase(loginAsync.fulfilled,(state,payload)=>{
            state.loginPageLoading = false
            console.log(payload)
            state.isAutheticated =true
            state.user = {
                id:payload.payload.id,
                name:payload.payload.name,
                token:payload.payload.token,
                userStatus:payload.payload?.userStatus
            }
        }).addCase(loginAsync.rejected,(state,payload)=>{
            state.loginPageLoading = false
            state.isAutheticated = false
            console.log(payload)
            state.errorMessage=JSON.stringify(payload?.payload)
        }).addCase(getProfile.fulfilled,(state,payload)=>{
            console.log("succefgusalsals askaksalslas")
            state.isAutheticated = true,
            state.user = {
                id:payload.payload.id,
                name:payload.payload.name,
                token:payload.payload.token,
                userStatus:payload.payload?.userStatus
            }
            state.isAutheticatedPending=false;
        }).addCase(getProfile.rejected,(state,payload)=>{
            console.log("rhceted hjasashja")
            state.isAutheticated = false
            state.isAutheticatedPending=false;
        }).addCase(getProfile.pending,(state,payload)=>{
            state.isAutheticatedPending=true;
        }).addCase(logoutUser.pending,(state,payload)=>{
            state.loading=true;
        }).addCase(logoutUser.fulfilled,(state,payload)=>{
            state.user = undefined
            state.loading=false;
        }).addCase(logoutUser.rejected,(state,payload)=>{
            state.loading=false;
        })
   },
})

export default BrokerSlice.reducer;
export const { updateAuthState,resetState } = BrokerSlice.actions;