import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { ChatConversation, ChatMessage } from "@mui/x-chat/core";
import { getInitialConversations, getInitialThreads, stringToHexColor } from "../components/chat/chatHelper";

const fixTestsId = 'ac-fix-tests';
const addFeatureId = 'ac-add-feature';
const dangerousCmdId = 'ac-dangerous-cmd';

type ChatState = {
    threads:Record<string, ChatMessage[]>
    conversations:ChatConversation[]
    testState:string
}
const initialState:ChatState = {
    threads:{},
    conversations:[] as ChatConversation[],
    testState:"kasan"
}
export const sendMessage = createAsyncThunk("chat/sendmessage",async ()=>{

    return fetch("http://localhost:8080/ws/chat/3")


})
export const loadChatHistory = createAsyncThunk("/user//chat/history",async (id:string,{rejectWithValue})=>{
    return fetch('http://localhost:8080/user/chat/history',{
        method:"POST",
        credentials: 'include',
        headers:{
            'Content-Type': 'text/plain'
        },
        body:id
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    })
    .catch(e=>{
        if(!e.response){
             return rejectWithValue('Internal server error');
        }
        console.log(e);
        return rejectWithValue(e.response.data.message || 'history loading failed');
    })

})
function createAvatarDataUrl(
    label: string,
    background: string,
    foreground = '#ffffff',
  ) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="24" fill="${background}"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" font-family="Arial, sans-serif" font-size="28" font-weight="600" fill="${foreground}">${label}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }
const ChatSlice = createSlice({
    name:"chat",
    initialState:initialState, 
    reducers:{
        addToThreads : (state,action)=>{
            state.threads = action.payload
        },
        addToConversations :(state,action)=>{
            state.conversations = action.payload
        },
        changeTestState : (state,action)=>{
            state.testState = action.payload
        }
    },
    extraReducers(builder){
         builder.addCase(loadChatHistory.pending,(state,payload)=>{
                    // state.loading = true
                 }).addCase(loadChatHistory.fulfilled,(state,payload)=>{
                    // state.loading = false
                    console.log("setting chatslic set state wdahshasjajhsajhsajshajsjhasjha")
                    state.conversations = payload.payload?.chatConversationDTOs
                    state.threads = payload.payload?.map
                    console.log(state.threads)
                    console.log("setting chatslic set state wdahshasjajhsajhsajshajsjhasjha")
                 }).addCase(loadChatHistory.rejected,(state,payload)=>{
                    // state.loading = false
                 })
    }

})

export const {addToThreads,addToConversations,changeTestState} = ChatSlice.actions
export default ChatSlice.reducer