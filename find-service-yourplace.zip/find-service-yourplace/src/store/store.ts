import { configureStore } from "@reduxjs/toolkit";
import ChatSlice from './chatSlice';
import CountrySlice from './countrySlice';
import BrokerSlice from './brokerSlice';
import MatchMakerSlice from './matchmakerSlice';
import FriendSlice from './friendSlice';

export const store = configureStore({
    reducer:{
      chat:ChatSlice,
      broker:BrokerSlice,
      matchMaker:MatchMakerSlice,
      countries:CountrySlice,
      friends:FriendSlice
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
          serializableCheck: false,
        })
})

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;