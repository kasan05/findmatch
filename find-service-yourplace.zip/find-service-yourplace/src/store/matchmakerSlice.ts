import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { MatchMaker } from "../types/MatchMaker";
import type { MatchMakerSearchProfile } from "../types/MatchMakerSearchProfile";
import type { FriendRequest } from "../components/Registration/types/FriendRequest";
import type { Page } from "../types/Page";
import JSZip from 'jszip';


export const  addAditionalDetailsToMatchMaker = createAsyncThunk("match-maker/additionalInfo",async (additionalData:FormData,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker',{
            method:"PUT",
        body:additionalData,
            credentials: 'include'
        }).then(res=>{
            console.log(res.status)
            if(res.status!=200){
                  return rejectWithValue("Internal Server Error");
            }
            return res.json()
        })
        .catch(e=>{
            if(!e.response){
                return rejectWithValue('Server is Down');
            }
            return rejectWithValue(e.response.data.message);
        })
})
// const sleep = (ms: number): Promise<void> => {
//     return new Promise((resolve) => setTimeout(resolve, ms));
//   };
export const loadMatchMakerProfile = createAsyncThunk("match-maker/profile",async (a,{rejectWithValue})=>{
    // await sleep(10000);
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/profile',{
         method:"POST",
         credentials:'include'   
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})
export const loadMatchMakerProfileData = createAsyncThunk("match-maker/profile/data",async (a,{rejectWithValue})=>{
    // await sleep(10000);
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/profile/data',{
         method:"POST",
         credentials:'include'   
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})
const sleep = (ms: number): Promise<void> => 
    new Promise((resolve) => setTimeout(resolve, ms));
  
export const loadMatchMakerProfileImages = createAsyncThunk("match-maker/profile/images",async (a,{rejectWithValue})=>{
    // await sleep(10000);
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/profile/images',{
         method:"POST",
         credentials:'include'   
    }).then(async res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            const arrayBuffer = await res.arrayBuffer();
            const  zip =  await JSZip.loadAsync(arrayBuffer);
            const imageFiles = [];
            for (const relativePath in zip.files) {
                const file = zip.files[relativePath];
                const base64Data = await file.async('base64'); 
                imageFiles.push(base64Data);
            }
            return imageFiles;
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})
export const loadMatchMakerFriendProfile = createAsyncThunk("match-maker/profile/friend",async (id:string,{rejectWithValue})=>{
    // await sleep(10000);
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/profile/friend',{
         method:"POST",
         headers:{
            'Content-Type': 'text/plain'
        },
         body:id,
         credentials:'include'   
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})

export const loadPersonnelData = createAsyncThunk("match-maker/personalData", async (a,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/personnel-data',{
        method:"GET",
        credentials:'include'   
    }).then(res=>{
        if(res.status!=200){
            console.log("res.status shdsddsdhsddsd")
            return rejectWithValue("Internal Server Error");
        }else{
            console.log("res.json()")
            return res.json();
        }
    }).catch(e=>{
        console.log(e)
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
    
})
export const sendFrindRequest = createAsyncThunk("match-maker/friend-request/send",async(id:number,{rejectWithValue})=>{
    const friendRequest:FriendRequest ={
        senderId:null,
        receiverId: id,
        status: ""
    }
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/friend',{
        method:"POST",
        headers:{
            'Content-Type': 'application/json'
        },
        body:JSON.stringify(friendRequest),
        credentials:'include'
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})
export const loadMatchMakerDataForSearchPage = createAsyncThunk("match-maker/data",async(page:Page,{rejectWithValue})=>{
    return fetch('https://jb189yg024.execute-api.ap-south-1.amazonaws.com/match-maker/data',{
        method:"POST",
        signal:page.signal ?? undefined,
        credentials:'include',
        headers:{
            'Content-Type': 'application/json'
        },
        body:JSON.stringify(page)
    }).then(res=>{
        if(res.status!=200){
            return rejectWithValue("Internal Server Error");
        }else{
            console.log("waiting and return response sucesfulsldsldlsdlsdlsd")
            return res.json();
        }
    }).catch(e=>{
        if(!e.response){
            return rejectWithValue("Internal Server Error");
        }
        return rejectWithValue(e.response.data.message);
    })
})

type MatchMakerState = {
loading :boolean,
imageLoading :boolean
 images:Array<String>
 matchmaker:MatchMaker,
 castes:Array<String>,
 countries:Array<String>,
 maritalStatuses:Array<String>,
 genders:Array<String>,
 professions:Array<String>,
 religions:Array<String>,
 matchMakerSearchProfiles:MatchMakerSearchProfile[],
 totalSearchCount:number,
 ProfileImageViewerPromise:any
 ProfileImageViewerPromiseErr:string | null
}


const initialState:MatchMakerState = {
    loading:false,
    imageLoading:false,
    images:[],
    matchmaker:{} as MatchMaker,
    castes:[],
    countries:[],
    maritalStatuses:[],
    genders:[],
    professions:[],
    religions:[],
    matchMakerSearchProfiles:[],
    totalSearchCount:0,
    ProfileImageViewerPromise:null,
    ProfileImageViewerPromiseErr:null
}

const MatchMakerSlice = createSlice({
name:"MatchMaker",
initialState: initialState,
reducers:{
    setProfileImageViewerPromise:(state,action)=>{
        state.ProfileImageViewerPromise = action.payload
    }
},
extraReducers(builder){
    builder.addCase(addAditionalDetailsToMatchMaker.pending,(state,payload)=>{
        state.loading=true
    }).addCase(addAditionalDetailsToMatchMaker.fulfilled,(state,payload)=>{
        state.loading=false
    }).addCase(addAditionalDetailsToMatchMaker.rejected,(state,payload)=>{
        state.loading=false
    }).addCase(loadMatchMakerProfile.pending,(state,payload)=>{
        state.loading=true
    }).addCase(loadMatchMakerProfile.fulfilled,(state,payload)=>{
        state.loading=false
        console.log(payload)
        state.images = payload.payload.images
        state.matchmaker = payload.payload.matchMakerDto
    }).addCase(loadMatchMakerProfile.rejected,(state,payload)=>{
        state.loading=false
    }).addCase(loadMatchMakerProfileImages.pending,(state,payload)=>{
        state.imageLoading=true
    }).addCase(loadMatchMakerProfileImages.fulfilled,(state,payload)=>{
        state.imageLoading=false
        state.images = payload?.payload;
    }).addCase(loadMatchMakerProfileImages.rejected,(state,payload)=>{
        state.imageLoading=false
        state.ProfileImageViewerPromiseErr ="ProfileImageViewerPromiseErr"
    }).addCase(loadMatchMakerProfileData.pending,(state,payload)=>{
        state.loading=true
    }).addCase(loadMatchMakerProfileData.fulfilled,(state,payload)=>{
        state.loading=false
        state.matchmaker = payload?.payload;
    }).addCase(loadMatchMakerProfileData.rejected,(state,payload)=>{
        state.loading=false
    }).addCase(loadPersonnelData.pending,(state,payload)=>{
        state.loading=true
    }).addCase(loadPersonnelData.fulfilled,(state,payload)=>{
        state.loading=false
        state.castes = payload.payload.castes
        state.countries = payload.payload.countries
        state.maritalStatuses = payload.payload.maritalStatuses
        state.genders = payload.payload.genders
        state.professions = payload.payload.professions
        state.religions = payload.payload.religions
    }).addCase(loadPersonnelData.rejected,(state,payload)=>{
        state.loading=false
    }).addCase(loadMatchMakerDataForSearchPage.pending,(state,payload)=>{
        state.loading=true
    }).addCase(loadMatchMakerDataForSearchPage.fulfilled,(state,payload)=>{
        state.loading=false
        state.matchMakerSearchProfiles = payload.payload?.searchDTOS
        state.totalSearchCount = payload.payload?.total
    }).addCase(loadMatchMakerDataForSearchPage.rejected,(state,payload)=>{
        state.loading=false
    }).addCase(loadMatchMakerFriendProfile.pending,(state,payload)=>{
        state.loading=true
    }).addCase(loadMatchMakerFriendProfile.fulfilled,(state,payload)=>{
        state.loading=false
        console.log(payload)
        state.images = payload.payload.images
        state.matchmaker = payload.payload.matchMakerDto
    }).addCase(loadMatchMakerFriendProfile.rejected,(state,payload)=>{
        state.loading=false
    })
}
});
export const {setProfileImageViewerPromise} = MatchMakerSlice.actions;
export  default MatchMakerSlice.reducer;


