import {  Avatar, Box, Button, ButtonGroup, Card, CardContent, Grid, Stack, TablePagination, Tooltip, Typography, useMediaQuery } from "@mui/material"
import { useCallback, useEffect, useState } from "react"
import { color, motion } from 'framer-motion';
import "./Featuredservice.css";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { loadMatchMakerDataForSearchPage, sendFrindRequest } from "../../store/matchmakerSlice";
import Lotus from '../../assets/images/lotus.png';
import type { MatchMakerSearchProfile } from "../../types/MatchMakerSearchProfile";
import PersonIcon from '@mui/icons-material/Person';
import TextsmsIcon from '@mui/icons-material/Textsms';
import LocationPinIcon from '@mui/icons-material/LocationPin';
import { useNavigate } from "react-router-dom";
import type { Page } from "../../types/Page";
import type { FilterInput } from "../../types/FilterInput";
import EmailIcon from '@mui/icons-material/Email';

interface FeaturedServiceProps{
    passRowPerPage:(rPerPage:number)=>void,
    passPage:(pageData:number)=>void
}
const FeaturedService:React.FC<FeaturedServiceProps> = ({passRowPerPage,passPage})=>{
    const [page, setPage] = useState(0);
    const totalSearchCount = useAppSelector(state=>state.matchMaker?.totalSearchCount)
    const navigate = useNavigate();
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const dispatch = useAppDispatch();
    const [currReceiverIdArray,setCurrReceiverIdArray] = useState<Array<number>>([]);
    const [pendingReceiverIdArray,setPendingReceiverIdArray] = useState<Array<number>>([]);
    const matchMakerSearchProfiles = useAppSelector(state=>state.matchMaker.matchMakerSearchProfiles);
    const isMobile = useMediaQuery(theme=>theme.breakpoints.down("sm"));
    const loading = useAppSelector(state=>state.matchMaker?.loading)
    const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null,newPage: number) => {
        setPage(newPage);
        passPage(newPage);
      };
    const displayFriendProfile =(matchMakerId:string)=>{
        navigate("/match-maker/profile/friend",{state:{id:matchMakerId}})
    }
      const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        passRowPerPage(parseInt(event.target.value, 10));
        setPage(0);
        passPage(0);
      };
      const textFriend = (matchMakerSearchProfile:MatchMakerSearchProfile)=>{
        console.log(":textFriend sssdsdsd")
        console.log(matchMakerSearchProfile);
        console.log(":textFriend sssdsdsd")
             navigate("/chat/friend",{state:{id:matchMakerSearchProfile?.id+":"+matchMakerSearchProfile?.name}})
            return;
      }
      useEffect(()=>{
        passRowPerPage(rowsPerPage);
        passPage(page);
        console.log("matchMakerSearchProfiles csahgsjasjajsasas changes ")
        console.log(matchMakerSearchProfiles)
        console.log("matchMakerSearchProfiles csahgsjasjajsasas changes ")
      },[matchMakerSearchProfiles])
      useEffect(()=>{
        passRowPerPage(rowsPerPage);
        passPage(page);
        const pageObj:Page = {
            limit:rowsPerPage,
            offset:page*rowsPerPage,
            filterInput:{} as FilterInput
        }
        dispatch(loadMatchMakerDataForSearchPage(pageObj)).unwrap();
      },[dispatch])
      const onConnect = useCallback((id:number)=>{
        setCurrReceiverIdArray(preIds=>{
            const arr = preIds || [];
            return [...arr,id];
        })
         dispatch(sendFrindRequest(id)).unwrap().then(res=>{
            setCurrReceiverIdArray(preIds=>preIds?.filter(item=>item!=id)??[])
            setPendingReceiverIdArray(preIds=>{
                const arr = preIds || [];
            return [...arr,id];
            });
         })
      },[dispatch])
    return(
      
        <Grid
       container
       spacing={2}
       padding={isMobile?5:0}
       size={{xs:12,sm:12,md:12,lg:12}} 
       justifyContent={"left"}
       alignItems={"left"}
      >
            {
                matchMakerSearchProfiles.map((matchMakerSearchProfile:MatchMakerSearchProfile,index:number)=>(
                    <Grid size={{xs:12,sm:6,md:4,lg:4}}  key={index}>
                                 <Box
            component={motion.div} // Tells MUI to use Framer Motion
            initial={{ opacity: -1, y: 50 ,scale:0.6}}
            whileInView={{ opacity: 1, y: 0,scale:1 }} // Triggers on scroll
            viewport={{ once: false, margin: '-100px' }} // Animates only once when visible
            transition={{ duration: 0.4, ease: 'easeOut' }}
            >
                             <Card sx={{height:"300px",boxShadow:
                             matchMakerSearchProfile.friendRequestStatus && matchMakerSearchProfile.friendRequestStatus=="ACCEPTED"?
                                "0px 0px 19px -3px rgba(105,26,7,0.78)":
                                "0px 0px 20px 1px rgba(173,216,230,0.85)"}}>
                                    {/* <CardMedia
                                        component="img"
                                        height="150rem"
                                        width="10rem"
                                        image={fS.image}
                                        alt={fS.name}
                                      
                                    /> */}
                                    <CardContent>
                                        <Box sx={{display:"flex",flexDirection:"column",
                                            justifyContent:"center",alignItems:"center",
                                            gap:1
                                        }}>
                                            <Avatar
                                                alt="Unknown"
                                                src={Lotus}
                                                sx={{ width: 56, height: 56 }}
                                            />
                                        <Typography variant="body1">{matchMakerSearchProfile.profession}</Typography>
                                            <Stack display={"flex"} flexDirection={"row"} justifyContent={"center"}
                                            justifyItems={"center"}>
                                            <LocationPinIcon fontSize="small"/>
                                            <Typography variant="body1">{matchMakerSearchProfile.country?.charAt(0).toUpperCase()+
                                               matchMakerSearchProfile.country?.slice(1).toLowerCase() }</Typography>
                                            </Stack>
                                            <Typography variant="body1" color="text.secondary">
                                            {matchMakerSearchProfile.age} 
                                        </Typography>
                                        <Typography variant="body1" color="text.secondary">
                                        {matchMakerSearchProfile.gender}
                                        </Typography>
                                        <Typography variant="body1" color="text.secondary">
                                            {matchMakerSearchProfile.caste}
                                        </Typography>
                                       {matchMakerSearchProfile.friendRequestStatus && matchMakerSearchProfile.friendRequestStatus=="ACCEPTED"?
                                           <Box display={"flex"} flexDirection={"row"} justifyContent={"center"} alignItems={"center"}
                                           gap={1}> 
                                            <ButtonGroup variant="text" size="small">
                                           <Button>
                                            <Typography sx={{background:"",cursor: 'pointer','&:hover': { color: '#691A07',transform:"scale(1.1)" }}} variant="body2"  color="black">
                                            <Tooltip title="Profile"><PersonIcon sx={{color:"#691A07"}} onClick={()=>displayFriendProfile(matchMakerSearchProfile?.id)}/></Tooltip>
                                        </Typography></Button>
                                        <Button>
                                              <Typography sx={{cursor: 'pointer','&:hover': { color: '#691A07',transform:"scale(1.1)" }}} variant="body2" color="black">
                                              <Tooltip title="Message"><EmailIcon  sx={{color:"#691A07"}} onClick={()=>textFriend(matchMakerSearchProfile)}/></Tooltip>
                                        </Typography></Button>
                                        </ButtonGroup>
                                          </Box>
                                       
                                       :(<Button disabled={matchMakerSearchProfile.friendRequestStatus!=null && matchMakerSearchProfile.friendRequestStatus!=undefined
                                            && matchMakerSearchProfile.friendRequestStatus.trim().length>0
                                        } sx={{mt:2}} variant='contained' onClick={(e:React.MouseEvent<HTMLButtonElement>)=>onConnect(Number(matchMakerSearchProfile.id))}>
                                            {!matchMakerSearchProfile.friendRequestStatus && <Typography variant="h1" sx={{fontSize:{xs:'0.8rem',md:'0.8rem'}}}>{currReceiverIdArray.includes(Number(matchMakerSearchProfile.id))?'connecting...':
                                            pendingReceiverIdArray.includes(Number(matchMakerSearchProfile.id))?'PENDING':"connect"}
                                            </Typography>}
                                            <Typography variant="h1" sx={{fontSize:{xs:'0.8rem',md:'0.8rem'}}}>{ matchMakerSearchProfile.friendRequestStatus==="PENDING"?"PENDING":""}</Typography>
                                            </Button>)}
                                                
                                        </Box>
                                    </CardContent>
                                </Card> </Box>  </Grid>
                      
                ))
            }
            <Grid size={12}>
                <Box sx={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
            <TablePagination
                component="div"
                count={totalSearchCount}
                page={page}
                onPageChange={handleChangePage}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                /></Box>
            </Grid>
            </Grid>)
}

export default FeaturedService;