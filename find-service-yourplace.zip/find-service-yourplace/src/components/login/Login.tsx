import { Alert, Avatar, Box, Button, Card, CardContent, CardHeader, CircularProgress, Container, LinearProgress, Stack, TextField, Typography, useMediaQuery } from "@mui/material";
import LoginIcon from '@mui/icons-material/Login';
import { useActionState } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { loginAsync } from "../../store/brokerSlice";
import type { UserDto } from "../../types/UserDto";
import { redirect, useNavigate } from "react-router-dom";
import "./Login.css";

const Login =()=>{
    const loginPageLoading = useAppSelector(state=>state.broker.loginPageLoading);
    const errorMessage = useAppSelector(state=>state.broker.errorMessage);
    const dispatch = useAppDispatch();
    const navigate = useNavigate();
    const [state,loginFormAction,isPending] = useActionState(login,{success:false,message:""});
    type FormDataState = {
        message?: string | null;
        errors?: Record<string, string[] | undefined>;
        success?: boolean;
      } | undefined
    async function login(prevState:FormDataState,formData:FormData){
      const email = formData.get("email");
      const password = formData.get("password");
      
      if(!email){
        return;
      }
      if(!password){

        return;
      }
      const userDto:UserDto = {
        email:email.toString(),
        password:password.toString()
      }
     try{
     dispatch(loginAsync(userDto)).unwrap()
      .then(result=>{
        console.log("printing result?.....")
        console.log(result?.userStatus==="INCOMPLETE_DATA")
        console.log("printing result?.....")
        if(result?.userStatus==="INCOMPLETE_DATA"){
          navigate("/match-maker/additional-details");
          return {success:true,message:""}
        }
         navigate("/match-maker/profile");
         return {success:true,message:""}
      });
      
     }catch(e){
      navigate("/login")
      return {success:false,message:""}
     }
    }
    const onChangeUserName = (e:React.ChangeEvent<HTMLInputElement>)=>{

    }
    const onChangePassword = (e:React.ChangeEvent<HTMLInputElement>)=>{

    }
    
    const isMobile = useMediaQuery(theme=>theme.breakpoints.down("sm"));

   return(<>
    <Box display={"flex"} flexDirection={"column"} sx={{opacity:loginPageLoading?0.1:1}} justifyContent={"center"} alignContent={"center"} height={"80vh"} flexWrap={"wrap"}>
    <Card sx={{width:isMobile? "80vw":"50vw",margin:"0 auto"}} elevation={0}>
    <CardHeader title={
          <Stack direction={"row"} spacing={1} justifyContent={"center"} alignItems={"center"}>
          <Avatar  sx={{background:"#ADD8E6"}}><LoginIcon/></Avatar>
          <Typography sx={{fontSize:{xs:'0.8rem',md:'0.9rem',fontWeight:"500"}}}>LOGIN</Typography>
          </Stack>
        } />
        <CardContent>
        <Container component="main" maxWidth="xs">
        
       <form action={loginFormAction}>
       <Stack direction={"column"} spacing={2}>
       <TextField
       type="email"
          name="email"
            label="Email"
            onChange={onChangeUserName}
            fullWidth
            />
            <TextField
            name="password"
            type="password"
            label="Password"
            onChange={onChangePassword}
            fullWidth
            />
            {errorMessage!=null && errorMessage!="" && 
              <Alert
              sx={{display:"flex",flexDirection:"row",alignItems:"center",justifyContent:"center",gap:0}}
            severity="error"
            >
           
                <Typography sx={{textAlign:"center"}}>{errorMessage.replaceAll('"', '')}</Typography>
            
              </Alert>
              }
           <Button fullWidth variant="contained" disabled={loginPageLoading?true:false}type="submit">SUBMIT</Button>
           </Stack>
       </form>
        </Container>
        </CardContent>
    </Card>
    </Box>
    {loginPageLoading && 
    <div style={
          {
            color:"#ADD8E6",
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)', // Offsets the bar's own height/width to be perfectly centered
           zIndex:1
          }
        }>
  <Box sx={{ width: 100 ,display:"flex",flexDirection:"column",gap:1,color:"#ADD8E6"}}>
    <Typography  sx={{fontSize:{fontWeight:"500"}}}>FindUrMatch</Typography>
      <LinearProgress   />
    </Box>

        </div>
   
    }</>
   );

}

export default Login;