import { Alert, Avatar, Box, Button, Card, CardContent, CardHeader, CircularProgress, Container, IconButton, LinearProgress, Stack, TextField, Typography, useMediaQuery } from "@mui/material";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { createTheme, StyledEngineProvider } from '@mui/material/styles';
import { DatePicker, type DateValidationError, type PickerChangeHandlerContext } from "@mui/x-date-pickers";
import "./Registration.css"
import type {} from '@mui/x-date-pickers/themeAugmentation';
import AddAPhotoIcon from '@mui/icons-material/AddAPhoto';
import { useActionState, useCallback, useEffect, useRef, useState, type Dispatch, type SetStateAction } from "react";
import passport from "../../assets/images/passport.png";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import type { RegistrationType } from "./types/RegistrationType";
import { useNavigate } from "react-router-dom";
import type { Dayjs } from "dayjs";
import Webcam from 'react-webcam';
import { VerifiedUser } from "@mui/icons-material";
import CameraIcon from '@mui/icons-material/Camera';
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { createBrokerAsync, resetState } from "../../store/brokerSlice";

const theme = createTheme({

});
const Registration = (registrationType:RegistrationType)=>{
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
    const [passportName,setPassportName] = useState("");
    const[cameraPhoto,setCameraPhoto] = useState<File |null >(null);
    const [emailVal,setEmailVal] = useState("");
    const [passwordVal,setpasswordVal] = useState("");
    const [reTypePasswordVal,setReTypePasswordVal] = useState("");
    const [name,setName] = useState("");
    const [nameErr,setNameErr] = useState(false);
    const [datPickerVal,setDatPickerVal] = useState("");
    const [passportFileVal,setPassportFileVal] = useState<File | null>(null);
    const [page,setPage]=useState<number>(0);
    const [datPickerError,setDatPickerError] = useState(false);
    const[passwordErrr,setpasswordErrr]=useState(false);
    const[reTypePasswordErrr,setReTypePasswordErrr]=useState(false);
    const[passportFileErr,setPassportFileErr]=useState(false);
    const webcamRef = useRef<Webcam>(null);
    const [imgSrc, setImgSrc] = useState<string | null>(null);
    const dispath = useAppDispatch();
    const loading = useAppSelector(state=>state.broker.loading);
    const submissionSuccessState = useAppSelector(state=>state.broker.submissionSuccessState);
    // Capture function
    const capture = useCallback(() => {
      if (webcamRef.current) {
        const imageSrc = webcamRef.current.getScreenshot();
        setImgSrc(imageSrc);
        if(imageSrc){
          setCameraPhoto(convertBase64ToFile(imageSrc,"cameraPhoto.jpeg"));
        }
      }
    }, [webcamRef]);
  
    const convertBase64ToFile = (base64Data:string, filename:string) => {
      const arr = base64Data.split(',');
      const mime = arr[0].match(/:(.*?);/)?.[1];
      const bstr = atob(arr[1]); // Decode base64 string
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      
      return new File([u8arr], filename, { type: mime }); // Create standard File object
    };
    // Retake function
    const retake = () => {
      setImgSrc(null);
    };
    const onEmailChange = (e:React.ChangeEvent<HTMLInputElement>)=>{
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      const email = e.target.value;
      setEmailVal(email);
      if(email && emailRegex.test(email)){
        setEmailError(false);
      }
    }
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const loaderStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)', // Offsets the bar's own height/width to be perfectly centered
  };
  const [facingMode, setFacingMode] = useState("user"); 
  const [state, formAction, isPending] = useActionState(createBroker, {success:false,message:""});
  const [progress,setProgress] = useState(0);
  const [emailError,setEmailError] = useState(false);
  const errorMessageRegistration = useAppSelector(state=>state.broker.errorMessageRegistration);
  const onImageFileUpload = (event:React.ChangeEvent<HTMLInputElement>)=>{
    if(event.target.files){
      setPassportFileErr(false);
      setPassportFileVal(event.target.files[0]);
      setPassportName(URL.createObjectURL(event.target.files[0]));
    }
  }

  const handleButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
   type FormDataState = {
    message?: string | null;
    errors?: Record<string, string[] | undefined>;
    success?: boolean;
  }
  const onNext =()=>{
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if(!name){
      setNameErr(true);
      return;
    }
    if(!emailVal){
      setEmailError(true);
      return;
    }else{
      if(!emailRegex.test(emailVal.toString())){
        setEmailError(true);
        return;
      }
    }
    if(!datPickerVal){
      setDatPickerError(true);
      return;
  }
  if(!passwordVal){
    setpasswordErrr(true);
    return;
  }
  if(!reTypePasswordVal){
    setReTypePasswordErrr(true);
    return;
  }
  if(passwordVal !== reTypePasswordVal){
      setpasswordErrr(true);
      setReTypePasswordErrr(true);
      return;
  }
  console.log(passportFileVal);
  if(!passportFileVal){
    setPassportFileErr(true);
    return;
  }
  setPage(1);
  }
  async function createBroker(prevState:FormDataState,formData:FormData){
   
    console.log(emailVal);
    console.log(datPickerVal);
    console.log(passwordVal);
    console.log(reTypePasswordVal);
    console.log(passportFileVal);
    console.log(cameraPhoto);

    const data = new FormData();
      data.append("name",name);
      data.append("email",emailVal);
      data.append("password",passwordVal);
      data.append("userType","MATCH_MAKER");
      data.append("datOfBirth",datPickerVal);
      data.append("cameraPhoto",cameraPhoto as File);
      data.append("passport",passportFileVal as File);


    const r = dispath(createBrokerAsync(data)).unwrap();
    return {success:true,message:""}
  }
  const onChangeDatePicker = (value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>)=>{
    setDatPickerVal(value!=null?value?.format("YYYY-MM-DD"):"");
    setDatPickerError(false);
  }
  const onChangePassword = (e:React.ChangeEvent<HTMLInputElement>)=>{
    const pass = e.target.value;
    setpasswordVal(pass);
    if(pass){
      setpasswordErrr(false);
    }
  }
  const onChangeName = (e:React.ChangeEvent<HTMLInputElement>)=>{
    const nameVal = e.target.value;
    setName(nameVal);
    if(nameVal){
      setNameErr(false);
    }
  }
  const switchCamera = () => {
    setFacingMode((prevMode) => (prevMode === "user" ? "environment" : "user"));
  };
  const onChangeRetypePassword = (e:React.ChangeEvent<HTMLInputElement>)=>{
    const reTypePass = e.target.value;
    setReTypePasswordVal(reTypePass);
    if(reTypePass){
      setReTypePasswordErrr(false);
    }
  }
  const goLogin = ()=>{
    navigate("/login")
  }
  useEffect(()=>{
    console.log("resetting states");
    dispath(resetState);
  },[dispath])
    return (<><Container id="registration" style={{
      opacity:isPending?0.3:1.0
    }}>
            <Box sx={{
        display:"flex",
        width:"100%",
        flexDirection:"column",
        placeItems:"center",
        textAlign:"center",
    }}>
       <Box sx={{ width:isMobile?"100%":"50%",paddingTop:"5rem", display:"flex", flexDirection:"column",
        placeItems:"center",
        textAlign:"center",paddingBottom:"10vh"}}>
       {page==0 && !submissionSuccessState && <Card elevation={0}>
        <CardHeader title={
          <Stack direction={"row"} spacing={1} justifyContent={"center"} alignItems={"center"}>
          <Avatar  sx={{background:"#ADD8E6"}}><AccountCircleIcon/></Avatar>
          <Typography sx={{fontSize:{xs:'0.8rem',md:'0.9rem',fontWeight:"500"}}}>SIGNUP AS <b>{registrationType.type}</b></Typography>
          </Stack>
        } />
        <CardContent>
        <TextField sx={{pb:"2rem"}} onChange={onChangeName} error={nameErr} name="password" type="text" variant="filled" fullWidth label="Name"/>
        <TextField sx={{pb:"2rem"}}error={emailError} name="email" onChange={onEmailChange} type="email" variant="filled" fullWidth label="Email"/>
        {datePickerMobile(datPickerError,onChangeDatePicker)}
        <TextField sx={{pb:"2rem"}} onChange={onChangePassword} error={passwordErrr} name="password" type="password" variant="filled" fullWidth label="Password"/>
        <TextField sx={{pb:"2rem"}} onChange={onChangeRetypePassword} error={reTypePasswordErrr}   name="retypepass" type="password" variant="filled" fullWidth label="Retype Password"/>
        <input ref={fileInputRef} name="passportFile" accept="image/*" style={{ display: 'none' }} onChange={onImageFileUpload} type="file"/>
        <Stack direction={"row"} spacing={2} justifyContent={"center"} alignItems={"center"}>
          <Box sx={{
            width:"50%",
            display:"flex",
            flexDirection:"column",
            justifyContent:"center",
            alignItems:"center"
          }}>
            <img src={passportName?passportName:passport} width="50%" height="50%" style={{objectFit:"cover"}}/>
            {passportFileErr && <Typography variant="h5" sx={{color:"red", fontSize:{xs:'0.8rem',md:'1.3rem'},pb:'1rem'}}>!No file uploaded</Typography>}
          </Box>
          <Box sx={{
            width:"50%",
            display:"flex",
            flexDirection:"column",
            justifyContent:"center",
            alignItems:"center",

          }} >
          <Typography variant="h5" sx={{fontSize:{xs:'0.5rem',md:'1rem'},pb:'1rem'}}></Typography>
           <Button startIcon={<AddAPhotoIcon/>} fullWidth variant="contained" onClick={handleButtonClick}> Passport</Button>
          </Box>
        </Stack>
       <Button sx={{mt:"5rem"}}  onClick={onNext} fullWidth variant="contained">Next</Button>
        
        </CardContent>
       </Card>}
       {
        page==1 && !submissionSuccessState && errorMessageRegistration=="" && (<Card sx={{opacity:loading? 0.5:1}}>
          <CardHeader title={
          <Stack direction={"row"} spacing={1} justifyContent={"center"} alignItems={"center"}>
          <Avatar sx={{background:"#ADD8E6",fontWeight:"500"}}><VerifiedUser/></Avatar>
          <Typography sx={{fontSize:{xs:'0.8rem',md:'0.9rem'}}}>FACE IDENTIFICATION</Typography>
          </Stack>
        } />
           <CardContent>
          <Box display="flex" flexDirection="column" justifyContent="center" alignItems="center">
              {imgSrc ? (
          <img src={imgSrc} alt="Captured" style={{ width: '100%', borderRadius: 8 }} />
        ) : (
                      <Webcam
                     
                        audio={false}
                        ref={webcamRef}
                        screenshotFormat="image/jpeg"
                        videoConstraints={{ facingMode: 'user' }} 
                        style={{ width: '100%', borderRadius: 8 }}
                        mirrored={facingMode=="user"}
                      />
                  )}
                      {imgSrc ? (
                        <Button  disabled={loading?true:false}  startIcon={<CameraIcon/>} sx={{marginTop:"1rem"}} variant="contained" fullWidth onClick={retake}>
                          Retake
                        </Button>
                      ) : (
                        <><Button  disabled={loading?true:false}  startIcon={<CameraIcon/>} sx={{marginTop:"1rem"}} variant="contained" fullWidth onClick={capture}>
                          Capture Photo
                        </Button>
                        <Button onClick={switchCamera}>switchCamera</Button></>
                      )}
              <Alert sx={{marginTop:"2rem",marginBottom:0}}
        severity="info">
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>The Purpose of taking This Photo is only for verification.</Typography> 
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}> The Person's Passport Photo should match with the Picture taken here</Typography> 
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}> Please make sure to upload clear Pictures to avoid Registration Failure</Typography> 
                      </Alert>
                      <form action={formAction}>
                        <Button sx={{mt:"2rem"}} disabled={loading?true:false} fullWidth variant="contained" type="submit">{loading?"submitting":"submit"}</Button>
                    </form>
              </Box>
          </CardContent>
        </Card>)
       }
       {(submissionSuccessState || errorMessageRegistration!="")&& (
        <Card elevation={0}>
           <CardHeader title={
          <Stack direction={"row"} spacing={1} justifyContent={"center"} alignItems={"center"}>
          <Avatar sx={{background:"#ADD8E6"}}><AppRegistrationIcon/></Avatar>
          <Typography  sx={{fontSize:{xs:'0.9rem',md:'1.1rem',fontWeight:"500"}}}>REGISTARTION REQUEST</Typography>
          </Stack>
        } />
          <CardContent>
       
    {errorMessageRegistration=="" ? (<Alert 
        severity="success">
                     
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>Your Request has been submitted successfully</Typography> 
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>After verification of your documents uploaded,</Typography> 
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>You will receive mail for your Registration Status</Typography> 
                     <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>Thank you for your patience</Typography> 
                     </Alert>):(
                      <Alert 
        severity="error">
          <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>{errorMessageRegistration.replaceAll(/['"]/g, '')}</Typography> 
          <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>Please Submit The Form Later</Typography> 
          <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>OR</Typography> 
          <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>Write to HelpDesk Support</Typography> 
          <Typography sx={{fontSize:{xs:'0.9rem',md:'1.1rem',textAlign:"center"}}}>info@matrimony@gmail.com</Typography> 
          </Alert>

                     )}

                     <Button sx={{mt:"5rem"}}  onClick={goLogin} fullWidth variant="contained" type="button">Login</Button>
                     </CardContent>
                     </Card>
       )}
       </Box>
    </Box>
    </Container>
     {loading && <div style={
      {
        color:"#ADD8E6",
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)', // Offsets the bar's own height/width to be perfectly centered
      }
    }><CircularProgress
variant="indeterminate"

/></div>}</>)
}

function datePickerMobile(datPickerError:boolean,onChangeDatePicker: (value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>) => void){
  return (
    <StyledEngineProvider>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
         <DatePicker onChange={onChangeDatePicker} name="datePicker" sx={{pb:"2rem"}} slotProps={{
      textField: {
        error:datPickerError,
        fullWidth: true,label:"Date of Birth"}}}/>
      </LocalizationProvider>
      </StyledEngineProvider>
    );
}


export default Registration;