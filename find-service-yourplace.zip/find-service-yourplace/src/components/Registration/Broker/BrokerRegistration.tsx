import Registration from "../Registration";

const BrokerRegistration = ()=>{
 return (<Registration  type="BROKER"/>);
}

export default BrokerRegistration;