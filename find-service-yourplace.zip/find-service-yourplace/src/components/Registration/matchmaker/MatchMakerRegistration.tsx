import Registration from "../Registration"

const MatchMakerRegistration = ()=>{

    return (<Registration type="MATCH MAKER" />);
}

export default MatchMakerRegistration;