export type MatchMakerBasicInfoType = {
    Gender:string
    Religion:string
    Profession:string
    Age:string
    Caste:string
}
