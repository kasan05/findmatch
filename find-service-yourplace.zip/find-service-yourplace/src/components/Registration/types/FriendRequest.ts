export type  FriendRequest={
    senderId?:number | null,
    receiverId:number,
    status:string
} 