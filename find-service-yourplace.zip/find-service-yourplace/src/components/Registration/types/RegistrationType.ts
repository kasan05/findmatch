export type RegistrationType = {

"type":string,


}