import { Avatar, BottomNavigation, BottomNavigationAction, Box, Card, CardContent, CardHeader, CardMedia, createTheme, Divider, duration, Grid, Icon, IconButton, List, ListItem, ListItemAvatar, ListItemButton, ListItemIcon, ListItemText, Stack, ThemeProvider, Typography, useMediaQuery } from "@mui/material";
import React from "react";
import  wedding from "../../assets/images/wedding.jpg";
import PhoneIcon from '@mui/icons-material/Phone';
import RateReviewIcon from '@mui/icons-material/RateReview';
import ContactMailIcon from '@mui/icons-material/ContactMail';
import BusinessIcon from '@mui/icons-material/Business';
import { red } from "@mui/material/colors";
import ContactPageIcon from '@mui/icons-material/ContactPage';
import { color, transform } from "framer-motion";
import ring from "../../assets/images/ring5.png";
import SearchIcon from '@mui/icons-material/Search';

const theme = createTheme({
    components:{
        MuiListItem:{
            styleOverrides:{
                root:{
                   
                }
            }
        }
    }
});
const Footer =()=>{
    const [value, setValue] = React.useState('CONTACT');
    const isMobile = useMediaQuery('(max-width:877px)');
    const handleChange = (event: React.SyntheticEvent, newValue: string) => {
        setValue(newValue);
      };
    return <ThemeProvider theme={theme}>
        <Box flexShrink={1} sx={{background:"#ADD8E6"}} width="100%" height={isMobile?"650px":"45vh"}>
            <Box  display={"flex"} flexDirection={isMobile?"column":"row"} justifyContent={"center"} alignItems={"center"}>
            <Box alignItems="center" justifyContent={"center"} flexDirection={"column"} display={"flex"} sx={{border:"1px red"}}  height={"100%"}  width={"100%"}  border={"2px blue"}>
                    <Card sx={{ backgroundColor: 'transparent',height:"100%",mt:isMobile?3:0}} elevation={0} >
                    <CardContent>
                         <Stack display={"flex"} justifyContent={"center"} alignItems={"center"} flexDirection={"column"} gap={2}>
                         
                         {/* <RateReviewIcon  sx={{ width:"2.2rem",height:"2.2rem",color:"#a60528"}}/> */}
                         <Stack  display={"flex"} justifyContent={"center"} alignItems={"center"} flexDirection={"row"} gap={1}>
                         <SearchIcon/>
                         <Typography variant="h1" sx={{fontSize:{xs:'1.6rem',md:'1.6rem'},fontWeight:"1000",lineHeight:1}}>FindUrmatch</Typography>
                         </Stack>
                         <Typography sx={{fontSize:{xs:'1.0rem',md:'1.0rem'},fontWeight:"900",ml:4,lineHeight:1}}>What People Says?</Typography>
                         </Stack>
                        <Box sx={{height:"120px"}} display={"flex"} justifyContent={"center"} alignItems={"center"} flexDirection={"row"} gap={1}>
                        <List 
                        sx={{ marginTop:2,backgroundColor: 'transparent', width: '100%', maxWidth: 360, bgcolor: 'transparent'}}>
                    <ListItem   alignItems="flex-start">
                        <ListItemAvatar>
                        <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" sx={{ bgcolor: "#a60528" }}/>
                        </ListItemAvatar>
                        <ListItemText
                        primary="Brunch this weekend?"
                        secondary={
                            <React.Fragment>
                            <Typography
                                component="span"
                                variant="body2"
                                sx={{ color: 'text.primary', display: 'inline' }}
                            >
                                Ali Connors
                            </Typography>
                            {" — I'll be in your neighborhood doing errands this…"}
                            </React.Fragment>
                        }
                        />
                    </ListItem>
                    {/* <ListItem   alignItems="flex-start">
                        <ListItemAvatar>
                        <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" sx={{ bgcolor: red[500] }}/>
                        </ListItemAvatar>
                        <ListItemText
                        primary="Brunch this weekend?"
                        secondary={
                            <React.Fragment>
                            <Typography
                                component="span"
                                variant="body2"
                                sx={{ color: 'text.primary', display: 'inline' }}
                            >
                                Ali Connors
                            </Typography>
                            {" — I'll be in your neighborhood doing errands this…"}
                            </React.Fragment>
                        }
                        />
                    </ListItem> */}
                    <Divider variant="inset" component="li" />
                    </List>
                        </Box>
                        </CardContent>
                    </Card>
            </Box>
        
        <Box alignItems="center" justifyContent={"center"}  display={"flex"} flexDirection={"column"} width={"100%"} height={"100%"} border={"2px blue"}>
                    <Card sx={{top:"50%", left:"50%",backgroundColor: 'transparent'}} elevation={0}>
                        <CardMedia component={"image"}>
                        <Box sx={{ bgcolor: 'transparent' }} mb={3} mt={3} >
                          <img src={wedding}  width="250rem" height="250rem" style={{ backgroundColor: 'transparent' }}/></Box>  </CardMedia>  
                    </Card>
                    </Box>
            
            <Box flexDirection={"column"} display={"flex"} 
            marginTop={2}
            alignItems={"center"}
             justifyContent={"center"} sx={{border:"1px red"}}  gap={2} width={"100%"} height={"100%"}>
                   
                    {isMobile?(
                        <BottomNavigation sx={{ width: "100%",backgroundColor: 'transparent' }} value={value} onChange={handleChange}>
                                
                                <BottomNavigationAction
                                    label="+6582070047"
                                    value="+6582070047"
                                    icon={<PhoneIcon  sx={{color:"#000080"}}/>}
                                />
                                <BottomNavigationAction
                                    label="kasan0506@gmail.com"
                                    value="kasan0506@gmail.com"
                                    icon={<ContactMailIcon sx={{color:"#000080"}}/>}
                                />
                                <BottomNavigationAction label="53 Grange Road,Singapore" value="53 Grange Road,Singapore" icon={<BusinessIcon sx={{color:"#000080"}}/>} />
                                </BottomNavigation>
                    ):(
                        <Card sx={{ backgroundColor: 'transparent',height:"100%"}} elevation={0} >
                        <CardContent>
                        <CardHeader
                         avatar={<ContactPageIcon sx={{color:"#000080"}}/>}
                         title= {
                             <Typography sx={{fontSize:{xs:'1.0rem',md:'1.0rem'},fontWeight:"1000",lineHeight:1}}>Contact</Typography>
                            }
                        />
                        <List>
                        <ListItem disablePadding>
                            <ListItemButton>
                            <ListItemIcon>
                            <PhoneIcon sx={{color:"#000080"}}/>
                            </ListItemIcon>
                            <ListItemText primary={ <Typography variant="body1">+6582070047</Typography>} />
                            </ListItemButton>
                        </ListItem>
                        <ListItem disablePadding>
                            <ListItemButton>
                            <ListItemIcon>
                            <ContactMailIcon sx={{color:"#000080"}}/>
                            </ListItemIcon>
                            <ListItemText primary={ <Typography variant="body1">kasan0506@gmail.com</Typography>} />
                            </ListItemButton>
                        </ListItem>
                        <ListItem disablePadding>
                            <ListItemButton>
                            <ListItemIcon>
                            <BusinessIcon sx={{color:"#000080"}}/>
                            </ListItemIcon>
                            <ListItemText primary={ <Typography variant="body1">53 Grange Road,Singapore</Typography>} />
                            </ListItemButton>
                        </ListItem>
                        </List> </CardContent>
                        </Card>)} 
                    </Box>
                    </Box>
                     </Box>
    </ThemeProvider>
}
export default Footer;