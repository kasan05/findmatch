import { Box, Button, Container, createTheme, Stack, ThemeProvider, Typography } from "@mui/material"
import Rose from '../../assets/images/rose.png'
import { useNavigate } from "react-router-dom"
import HandshakeIcon from '@mui/icons-material/Handshake';
import FavoriteIcon from '@mui/icons-material/Favorite';
import "./Hero.css";

const theme = createTheme({
    components:{
        MuiButton:{
            styleOverrides:{
              
            }
        }
    }
})
const Hero =()=>{
    
    const navigate = useNavigate();
    const onClickBrokerRegister = ()=>{
        window.scrollTo({
            top: 0,
            behavior: 'smooth' // Use 'auto' for instant scrolling
          });
        navigate("/broker/register")
    }
    const onClickMatchMakerRegister = ()=>{
        window.scrollTo({
            top: 0,
            behavior: 'smooth' // Use 'auto' for instant scrolling
          });
        navigate("/match-maker/register")
    }
    return(
       
    <Container id="home">
        <Stack 
        direction={{xs:"column",md:"row"}}
        spacing={2}
        sx={{
            width:"100%",
            justifyContent:"center",
            alignItems:"center",
            minHeight:"85vh"
        }}>
             <Box sx={{
                width:"50%",
                padding:2,
                textAlign:"center"
            }}>
                <div className="mainImage">
                <img
                    src={Rose} alt="rose" style={{
                        width:"100%"}}
                /></div>
            </Box>
            <Box sx={{
                width:{xs:"100%",md:"50%"},
                padding:"3rem 0",
                textAlign:"center",
                display:"flex",
                flexDirection:"column",
                gap:".5rem",
                placeItems:"center"
            }}>
                 <Stack direction="column" spacing={2}>
                    <Typography variant="h1" sx={{fontSize:{xs:'2rem',md:'2rem'},fontWeight:"1000",pb:'1rem',lineHeight:1}}>FindUrmatch</Typography>
                    <Typography variant="h1" sx={{fontSize:{xs:'0.9rem',md:'0.9rem',fontWeight:"500",lineHeight:1}}}>A Trusted Match Making Service</Typography>
                    <Typography variant="h1" sx={{fontSize:{xs:'0.9rem',md:'0.9rem',fontWeight:"500",lineHeight:1}}}>We value EveryOne's Privacy</Typography>
                    <Typography variant="h1" sx={{fontSize:{xs:'0.9rem',md:'0.9rem',fontWeight:"500",lineHeight:1}}}>True identity is welcome </Typography>
                <Typography variant="h1" sx={{fontSize:{xs:'0.9rem',md:'0.9rem',fontWeight:"500",lineHeight:1}}}>
                    Signup Here
                </Typography>
                <Stack 
                
            direction={{xs:"column",md:"row"}} 
            sx={{paddingTop:3,placeItems:"center"}}
            spacing={2}>
        
            <Button  
            endIcon={<HandshakeIcon/>}
            sx={{transition:"all 0.3s ease",
                "&:active":{transform:"translateY(-1px)"},
                "&:hover":{transform:" translateY(-3px)"},
                '&:hover .MuiButton-endIcon': {
                    transform: "translateX(4px)",
                    scale: 1.2,
                    color:"#a60528"
                    }
            ,boxShadow:"1px 0px 26px -1px rgba(142, 6, 6, 0.5)"}}  
            variant="contained" color="secondary" onClick={onClickBrokerRegister} 
            fullWidth >Broker </Button>
            <Button variant="contained" 
             endIcon={<FavoriteIcon/>}
             sx={{transition:"all 0.3s ease",
                "&:active":{transform:"translateY(-1px)"},
                "&:hover":{transform:" translateY(-3px)"},
                '&:hover .MuiButton-endIcon': {
                    transform: "translateX(4px)",
                    scale: 1.2,
                    color:"#a60528"
                    }
            ,boxShadow:"1px 0px 26px -1px rgba(142, 6, 6, 0.5)"}} 
            color="secondary" onClick={onClickMatchMakerRegister} fullWidth > partner</Button>
            </Stack>
                 </Stack>
            </Box>
        </Stack>

    </Container>)
}

export default Hero;