import { Alert, Avatar, Box, Button, Card, CardContent, Container, Grid, Stack, TablePagination, Typography } from "@mui/material";
import { motion } from "framer-motion";
import Lotus from '../../assets/images/lotus.png';
import type { MatchMakerSearchProfile } from "../../types/MatchMakerSearchProfile";
import React, { useCallback, useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { loadFriendRequest, respondToFriendRequest } from "../../store/friendSlice";
import DoneIcon from '@mui/icons-material/Done';
import ClearIcon from '@mui/icons-material/Clear';
import type { FriendRequest } from "../Registration/types/FriendRequest";
import NoAccountsIcon from '@mui/icons-material/NoAccounts';
import { Search } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

type userWithStatus = {
    id:string,
    status:"PENDING"|"ACCEPTED" | "REJECTED"
}

const Friendrequest = ()=>{

const friendRequests:Array<MatchMakerSearchProfile> = useAppSelector(state=>state.friends.friends);
const loading:boolean = useAppSelector(state=>state.friends.loading);
const navigate = useNavigate();
const AppUser = useAppSelector(state=>state.broker?.user);
 const [page, setPage] = useState(2);
 const [rejectedIds,setRejectedIds] = useState<Record<string,"PENDING"|"ACCEPTED" | "REJECTED">>({});
 const [acceptIds,setAcceptIds] = useState<Record<string,"PENDING"|"ACCEPTED" | "REJECTED">>({});
 const searchFriends = ()=>{
    navigate("/search")
 }
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const dispatch = useAppDispatch();
    useEffect(()=>{
        dispatch(loadFriendRequest());
    },[dispatch])
    const onAccept = useCallback((senderId:number)=>{
        setAcceptIds(prevRec=>({...prevRec,[senderId]:"PENDING"}));
        const friendRequestDTO:FriendRequest = {
            senderId:senderId ,
            receiverId: Number(AppUser?.id),
            status: "ACCEPTED"
        }
        console.log(friendRequestDTO)
        dispatch(respondToFriendRequest(friendRequestDTO)).unwrap().then(res=>{
            setAcceptIds(prevRec=>({...prevRec,[senderId]:"ACCEPTED"}));
        })
    },[acceptIds])
    const onReject = useCallback((senderId:number)=>{
        setRejectedIds(prevRec=>({...prevRec,[senderId]:"PENDING"}))
        const friendRequestDTO:FriendRequest = {
            senderId: senderId,
            receiverId: Number(AppUser?.id),
            status: "REJECTED"
        }
        console.log(friendRequestDTO)
        dispatch(respondToFriendRequest(friendRequestDTO)).unwrap().then(res=>{
            setRejectedIds(prevRec=>({...prevRec,[senderId]:"REJECTED"}))
        })
    },[acceptIds])
    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
      };
      const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null,newPage: number) => {
        setPage(newPage);
      };
    return(<Container sx={{padding:5}}>
         <Grid
       container
       spacing={2}
       size={{xs:12,sm:12,md:12,lg:12}} 
       justifyContent={"left"}
       alignItems={"left"}
      >
        { friendRequests.map((friendRequest:MatchMakerSearchProfile,index:number)=>(
        <Grid size={{xs:12,sm:6,md:4,lg:4}}  key={index}>
                                 <Box
            component={motion.div} // Tells MUI to use Framer Motion
            initial={{ opacity: -1, y: 50 ,scale:0.6}}
            whileInView={{ opacity: 1, y: 0,scale:1 }} // Triggers on scroll
            viewport={{ once: false, margin: '-100px' }} // Animates only once when visible
            transition={{ duration: 0.4, ease: 'easeOut' }}
            >
                             <Card>
                                    <CardContent>
                                        <Box sx={{display:"flex",flexDirection:"column",
                                            justifyContent:"center",alignItems:"center",
                                            gap:1
                                        }}>
                                            <Avatar
                                                alt="Unknown"
                                                src={Lotus}
                                                sx={{ width: 56, height: 56 }}
                                            />
                                        <Typography variant="body1">{friendRequest.profession}</Typography>
                                        <Typography variant="body1">{friendRequest.country}</Typography>
                                            <Typography variant="body1" color="text.secondary">
                                            {friendRequest.age} 
                                        </Typography>
                                        <Typography variant="body1" color="text.secondary">
                                        {friendRequest.gender}  
                                        </Typography>
                                        <Typography variant="body1" color="text.secondary">
                                            {friendRequest.caste}
                                        </Typography>
                                       <Stack direction={"row"} justifyContent={"center"} alignContent={"center"} spacing={1}>
                                        <Button  disabled={acceptIds[friendRequest.id]=="ACCEPTED"} 
                                        onClick={(e:React.MouseEvent<HTMLButtonElement>)=>onAccept(Number(friendRequest.id))} size={"small"} startIcon={<DoneIcon/>} sx={{mt:2,
                                             display:rejectedIds[friendRequest.id]==="REJECTED"?"none":""
                                        }} variant='contained' >
                                       <Typography>{acceptIds[friendRequest.id]=="PENDING" ?"Accepting...":
                                       acceptIds[friendRequest.id]=="ACCEPTED" ?"Accepted":"Accept"}</Typography>
                                            </Button>
                                        <Button  disabled={rejectedIds[friendRequest.id]=="REJECTED"} 
                                        onClick={(e:React.MouseEvent<HTMLButtonElement>)=>onReject(Number(friendRequest.id))} size={"small"}  startIcon={<ClearIcon/>}  sx={{mt:2,
                                            display:acceptIds[friendRequest.id]==="ACCEPTED"?"none":""
                                        }} variant='contained' >
                                       <Typography> {rejectedIds[friendRequest.id]=="PENDING" ?"Rejecting...":rejectedIds[friendRequest.id]==="REJECTED"?"Rejected":"Reject"}</Typography>
                                            </Button>
                                        </Stack>
                                        </Box>
                                    </CardContent>
                                </Card> </Box>  </Grid>
                      
                ))
            }
            {friendRequests.length==0 &&(<Grid size={12} justifyContent={"center"} alignItems={"center"} display={"flex"} height={"40vh"}>
                <Box sx={{display:"flex",flexDirection:"column",
                                            justifyContent:"center",alignItems:"center",
                                            gap:1,
                                            m:5,
                                           
                                        }}>
                                            <NoAccountsIcon /> 
                                                    <Typography variant="body1" color="text.secondary">
                                                      No Requests
                                                        </Typography>
                                                        <Button  onClick={searchFriends} startIcon={<Search/>}>Search</Button>
                                                        </Box>
                                                </Grid>) 
                                        }
            <Grid size={12}>
                {friendRequests.length>0 && <Box sx={{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
                    <TablePagination
                        component="div"
                        count={100}
                        page={page}
                        onPageChange={handleChangePage}
                        rowsPerPage={rowsPerPage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                        />
                </Box>}
            </Grid>
            </Grid>
           
    </Container>
)
}
export default Friendrequest;