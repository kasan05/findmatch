import { useLocation } from "react-router-dom";
import ChatScreen from "./ChatScreen";
import { useEffect } from "react";

const FriendChatScreen = ()=>{

    const location = useLocation();
    const id =location.state?.id;
   

    useEffect(()=>{
       
    },[])

    return(<ChatScreen userFromAnotherTabId={location.state?.id.split(":")[0]} userFromAnotherTabName={location.state?.id.split(":")[1]}/>)
}
export default FriendChatScreen;