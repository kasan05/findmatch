import { ChatBox } from "@mui/x-chat";
import { selectActiveConversation, type ChatAdapter, type ChatMessageChunk, type ChatRole, type ChatStreamEnvelope, type ChatUser } from "@mui/x-chat/core";
import {
    minimalConversation
  } from './demodata';
import {Autocomplete, Box, Button, Stack, TextField, ThemeProvider, Typography, useMediaQuery } from "@mui/material";
import { createTheme } from '@mui/material/styles';
import type {} from '@mui/x-chat/themeAugmentation';
import type { ChatConversation, ChatMessage, ChatMessageMetadata, ChatMessagePart, ChatMessagePartStatus, ChatMessageStatus } from "@mui/x-chat/types";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { getChatConversationDTO, getChatMessageUser, getInitialConversations, stringToHexColor } from "./chatHelper";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import AddIcon from '@mui/icons-material/Add';
import type { MatchMakerSearchProfile } from "../../types/MatchMakerSearchProfile";
import { loadFriends } from "../../store/friendSlice";
import type { ChatConversationDTO } from "../../types/ChatConversationDTO";
import type { ChatUserDTO } from "../../types/ChatUserDTO";
import type { AppChatMessage } from "../../types/AppChatMessage";
import { loadChatHistory } from "../../store/chatSlice";
import OnlineStatus from "./onlineStatus";
const fixTestsId = 'ac-fix-tests';
const addFeatureId = 'ac-add-feature';
const dangerousCmdId = 'ac-dangerous-cmd';
const theme = createTheme({
    palette:{
      primary:{
        main:"#ADD8E6"
      }
    },
    components:{
        MuiChatConversation:{
            styleOverrides:{
              root:{
                background:" #edebeb !important"
              },
              subtitle:{
                
              }
            
            }
        },
        MuiChatConversationList:{
          styleOverrides:{
            item:{
              padding:10,
              borderRadius:10
            }
          }
        },
        MuiAutocomplete:{
          
        },
        MuiButton:{
          styleOverrides:{
            root:{
              fontFamily:"'Montserrat', sans-serif"
            }
          }
        },
        MuiChatBox:{
          styleOverrides:{
           root:{
            background:" #edebeb !important",
            fontFamily:"'Montserrat', sans-serif"
           },
           conversationsPane:{
            fontFamily:"'Montserrat', sans-serif",
           }
           
          }
        },
        MuiChatComposer:{
          styleOverrides:{
            root:{
              margin:"1rem",
              fontFamily:"'Montserrat', sans-serif"
            }
          }
        },
        MuiChatMessage:{
          styleOverrides:{
            root:{
              fontFamily:"'Montserrat', sans-serif"
            }
          }
        },
        MuiTypography:{
          styleOverrides:{
            root:{
               fontFamily:"'Montserrat', sans-serif"
            }
          }
        }
        
    }
});

  
function createAvatarDataUrl(
    label: string,
    background: string,
    foreground = '#ffffff',
  ) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="24" fill="${background}"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" font-family="Arial, sans-serif" font-size="28" font-weight="600" fill="${foreground}">${label}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

const initialConversations: ChatConversation[] = getInitialConversations(fixTestsId,
  addFeatureId,dangerousCmdId
);
type MContent={
   chatConversationDTO:ChatConversationDTO,
  chatMessageUser:AppChatMessage
}
type SelectItem = {
  label:string,
  friend:MatchMakerSearchProfile
}
interface ChatScreenProps{
  userFromAnotherTabId?:string
  userFromAnotherTabName?:string
}
const ChatScreen :React.FC<ChatScreenProps> = ({userFromAnotherTabId,userFromAnotherTabName})=>{
  const friends = useAppSelector(state=>state.friends.friends);
  const conversationsFromStore = useAppSelector(state=>state.chat.conversations);
  const threadsFromStore = useAppSelector(state=>state.chat.threads);
  const [activeUserOnline,setActiveUserOnline]  = useState<boolean>();
  const dispatch  = useAppDispatch();
  const[receiver,setReceiver]=useState<MatchMakerSearchProfile>({} as MatchMakerSearchProfile);
  const[receiverName,setReceiverName]=useState<string>("");
  const [threads, setThreads] = React.useState<Record<string, ChatMessage[]>>(() =>
    Object.fromEntries(
     Object.entries(threadsFromStore).map(([id, msgs]) => [
       id,
       msgs.map((m:ChatMessage) => ({ ...m,author:{...m.author,
         avatarUrl: createAvatarDataUrl(m.author?.displayName?.[0] ?? '?'.toUpperCase(), stringToHexColor(m.author?.displayName?.[0] ?? '?'))?? ""
       }})),
     ]),
   ),
 );
 const [conversations, setConversations] = React.useState<ChatConversation[]>(() =>
   conversationsFromStore.map((c) => ({ ...c,
     participants:c.participants?.map(participant=>({
       ...participant,
       avatarUrl:  createAvatarDataUrl(participant?.displayName?.[0] ?? '?'.toUpperCase(), stringToHexColor(participant?.displayName?.[0] ?? '?'))
     }))
    })),
 );
  const prepareFriendList = (friends:Array<MatchMakerSearchProfile>):Array<SelectItem>=>{
      return friends.map(friend=>{
       return {
        label:friend.name,
        friend:friend
       }
      })
  }
  const[conIdRecords,setConIdRecords] = useState<Record<string,string>>({});
  const sender = {
    id:"aedca47d-9f9a-4cc4-a87f-a02651c71b5a",
    name:"Renu",
    token:"",
    userStatus:""
  }
  const senderUser:ChatUser = {
    id: sender.id,
    displayName: sender.name,
    avatarUrl: createAvatarDataUrl('C', '#d97757'),
    isOnline: true,
  };
    const isMobile = useMediaQuery(theme=>theme.breakpoints.down("sm"));
    const AppUser = useAppSelector(state=>state.broker.user?state.broker.user:{id:"",token:"",name:"",userStatus:""})
    const [messagesQueue, setMessagesQueue] = useState<MContent[]>([]);
    const assistantUser:ChatUser ={
      id: receiver?.id,
      displayName: receiver?.name,
      avatarUrl: createAvatarDataUrl(receiver?.name?receiver?.name?.charAt(0).toUpperCase():"Y", '#B82C16'),
      isOnline: true,
    }
    const currentUser:ChatUser = {
      id: AppUser?.id,
      displayName: AppUser.name,
      avatarUrl: createAvatarDataUrl(AppUser.name.charAt(0).toUpperCase(), stringToHexColor(AppUser.name)),
      isOnline: true,
    };
    const appStompClient = useRef(new Client());
    const role :ChatRole ="user"
    const mData : ChatMessageMetadata = {
          

    }
    const [conversationClicked, setConversationClicked] = useState<boolean>(false);
    const [enableSearch,setEnableSearch] = useState<boolean>(false);
    const [activeId, setActiveId] = React.useState<string>(() => conversationsFromStore && conversationsFromStore.length>0?conversationsFromStore[0].id:"");
    const initialThreads: Record<string, ChatMessage[]> = {}
    const name = useAppSelector(state=>state.chat.testState);
    

    function makeAssistantMessage(
      id: string,
      conversationId: string,
      createdAt: string,
      parts: ChatMessagePart[],
      status: ChatMessage['status'] = 'sent',
      author:ChatUser
    ): ChatMessage {
      return {
        id,
        conversationId,
        role: 'assistant',
        status,
        createdAt,
        author: author,
        parts,
      };
    }
    useEffect(()=>{
        //loading chat history
        console.log("loading chat history loading chat history")
        dispatch(loadChatHistory(AppUser?.id));
    },[dispatch])
    useEffect(()=>{
      console.log("threads chanshwhwbd sd s ds d sd s ds d s dsds")

      const updatedThreads: Record<string, ChatMessage[]> = Object.fromEntries(
        Object.entries(threadsFromStore).map(([id, msgs]) => [
          id,
          msgs.map((m:ChatMessage) => ({ ...m,author:{...m.author,
            avatarUrl: createAvatarDataUrl(m.author?.displayName?.charAt(0).toUpperCase() ?? '?'.toUpperCase(), stringToHexColor(m.author?.displayName ?? '?'))?? ""
          }})),
        ]),
      ) as Record<string, ChatMessage[]>;

      const updatedConversation:ChatConversation[] =  conversationsFromStore.map((c) => ({ ...c,
        avatarUrl:createAvatarDataUrl(c.title?.charAt(0).toUpperCase() ?? '?'.toUpperCase(), stringToHexColor(c.title ?? '?'))
       }));

      if(conversationsFromStore && conversationsFromStore.length>0){
        setActiveId(conversationsFromStore[0].id);
        const userArr :ChatUser[] = conversationsFromStore[0]?.participants ??[];
        if(String(userArr?.[0].id) ===String(AppUser?.id)){
          setReceiver((prevF)=>({...prevF,id:userArr?.[1].id,name:userArr?.[1].displayName ??""}))
          setReceiverName(userArr?.[1].displayName ??"");
          setActiveUserOnline(userArr?.[1].isOnline);
        }else{
          setReceiver((prevF)=>({...prevF,id:userArr?.[0].id,name:userArr?.[0].displayName ??""}))
          setReceiverName(userArr?.[0].displayName ??"");
          setActiveUserOnline(userArr?.[0].isOnline);
        }
        
      }
      setThreads(updatedThreads);
      setConversations(updatedConversation);
      
      console.log(threadsFromStore)
        console.log("threads chanshwhwbd sd s ds d sd s ds d s dsds")
    },[threadsFromStore,conversationsFromStore])
    useEffect(()=>{
      if(appStompClient.current==null || appStompClient.current==undefined || !appStompClient.current.connected){
        const socket = new SockJS('http://localhost:8080/ws');
      const client = new Client({
        webSocketFactory: () => socket,
        reconnectDelay: 5000,           // Avoid aggressive reconnection loops
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
        connectHeaders: {
          Authorization: "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrYXNhbjA1MDZAcHJvdG9uLm1lIiwiaWF0IjoxNzgyNjIzNjU0LCJleHAiOjE3ODI2MjcyNTR9.ITMNw2EqtOIxA9u46bwUC8Ins0bPQJGYTf1Z3fIXj_s", // Auth Header here
        },
        onConnect: () => {
          console.log('successfluy Connected::::::Kasan');
          //SUBSCRIBE TO MESSAGE
          const headers = { Authorization: "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrYXNhbjA1MDZAcHJvdG9uLm1lIiwiaWF0IjoxNzgyNjIzNjU0LCJleHAiOjE3ODI2MjcyNTR9.ITMNw2EqtOIxA9u46bwUC8Ins0bPQJGYTf1Z3fIXj_s",'content-type': 'application/json' };
          const dummyId="aedca47d-9f9a-4cc4-a87f-a02651c71b5a";
          console.log("when publisjing............")
          console.log(threads)
          console.log(activeId)
          console.log("when publisjing............")
          if (messagesQueue.length > 0) {
            messagesQueue.forEach(msg => {
              client.publish({
                destination: '/app/chat/'+receiver.id,
                headers: headers, 
                body: JSON.stringify({chatMessage:msg.chatMessageUser,chatConversationDTO:msg.chatConversationDTO}),
            });
            });
            setMessagesQueue([]); 
          }
          appStompClient.current.subscribe('/topic/message/'+AppUser.id, (message) => {
            
            const receivedMsg = JSON.parse(message.body);
            const  chatMssge:AppChatMessage = receivedMsg?.chatMessage;
            const  chatCon:ChatConversationDTO = receivedMsg?.chatConversationDTO;
            console.log("I print chatCon for subscribe debug purpose jdjsdjsds dsjhdsjdjsdjhsdhjsdhsjhdsjhdjsdjsjdsjdjsdhjsdjhshjdsjdjhs")
            console.log(chatCon)
            console.log("I print chatCon for subscribe debug purpose jdjsdjsds dsjhdsjdjsdjhsdhjsdhsjhdsjhdjsdjsjdsjdjsdhjsdjhshjdsjdjhs")
            console.log("receiving message");
            console.log(receivedMsg?.chatMessage);
            console.log("received message");
            // let conId:string;
            // let conId1:string;
            // if(receiver.id<AppUser.id){
            //  conId = receiver.id+"_"+AppUser.id;
            //  if(conId in conIdRecords){
            //   conId1 = conIdRecords[conId];
            //  }else{
            //   conId1 = crypto.randomUUID();
            //   setConIdRecords(prevIds=>({...prevIds,[conId]:conId1}))
            //  }
            // }else{
            //  conId = AppUser.id+"_"+receiver.id;
            //  if(conId in conIdRecords){
            //   conId1 = conIdRecords[conId];
            //  }else{
            //   conId1 = crypto.randomUUID();
            //   setConIdRecords(prevIds=>({...prevIds,[conId]:conId1}))
            //  }
            // }
            // console.log(conId1);
            // console.log(threads[conId1]);
            // if(!threads[conId1]){
            //   threads[conId1] = [] as ChatMessage[];
            //   }

            // const uniqueId: string = crypto.randomUUID();
            const cUser:ChatUser = {
              id: chatMssge.id,
              displayName: chatMssge?.author?.displayName,
              avatarUrl: createAvatarDataUrl(chatMssge?.author?.displayName?.charAt(0).toString(), stringToHexColor(chatMssge?.author?.displayName)),
              isOnline: chatMssge?.author?.isOnline,
              role: chatMssge?.role as ChatRole,
            }
            const assistantUserSub:ChatUser ={
              id: chatMssge?.author.id,
              displayName: chatMssge?.author.displayName,
              avatarUrl: createAvatarDataUrl(chatMssge?.author.displayName?chatMssge?.author.displayName.charAt(0).toUpperCase():"Y", stringToHexColor(chatMssge?.author.displayName)),
              isOnline: true,
            }
            const currentUserSub:ChatUser = {
              id: AppUser.id,
              displayName: AppUser.name,
              avatarUrl: createAvatarDataUrl(AppUser.name.charAt(0).toUpperCase(), stringToHexColor(AppUser.name)),
              isOnline: true,
            };
            const arr:ChatConversation =  {
              id: chatCon.id,
              title: chatCon.title,
              subtitle: chatCon.subtitle,
              participants: [assistantUserSub,currentUserSub],
              readState: 'read',
              unreadCount: chatCon.unreadCount,
              lastMessageAt: chatCon.lastMessageAt
            };       
            setActiveId(chatCon?.id)
            setConversations((prevCon)=>{
              if(!prevCon || prevCon.length==0) return [arr];
              return [...prevCon,...[arr]]
            })
            setReceiver((prevF)=>({...prevF,id:chatMssge?.author?.id,name:chatMssge?.author?.displayName}))
            setReceiverName(chatMssge?.author?.displayName);
            setActiveUserOnline(chatMssge?.author?.isOnline);
            setThreads((prevState)=>{
              const existingMessages = prevState[ chatMssge.conversationId] ?? [];
              return {
                ...prevState,
                [ chatMssge.conversationId]: [...existingMessages,  makeAssistantMessage(chatMssge.id, chatMssge.conversationId, chatMssge.createdAt, [
                  {
                    type:"text",
                    text: chatMssge?.parts[0].text,
                    state: chatMssge?.parts[0].state as ChatMessagePartStatus
                  }
                ],chatMssge?.status as ChatMessageStatus ,cUser)],
              };
            })
          });
        },
      });
      client.activate();
      appStompClient.current = client;
      return () => {
        if (appStompClient.current) {
          appStompClient.current.deactivate(); //
        }
      };
      }
    },[]);
    
    // const chatUser:ChatUser = {
    //     id:"235",
    //     displayName:"kasanupdated",
    //     avatarUrl:mark,
    //     isOnline:true,
    //     role:role,
    //     metadata: mData,   
    // }
    // const op:any ={
    //     agent:chatUser,
    //     delayMs: 150,
    //     respond:()=>"REsponsded to you"
    // }
    let c =3;
    const createWebSocketAdapter = (token: string): ChatAdapter => ({
      //  subscribe({ onEvent }){
      //   appStompClient.current.subscribe('/topic/message/2', (message) => {
      //     onEvent(JSON.parse(message.body));
      //   });
        
      // },
      
      async sendMessage({ message }) :Promise<any> {
        // Send message to Spring Boot @MessageMapping
        // Need a separate stomp client instance or accessible client for this
        // console.log("sending message ............................")
        // const socket = new SockJS('http://localhost:8080/ws');
        // console.log("sending message 1............................")
        // const client = new Client({
        //   webSocketFactory: () => socket,
        //   connectHeaders: {
        //     Authorization: "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrYXNhbjA1MDZAZ21haWwuY29tIiwiaWF0IjoxNzc4NzM3ODkxLCJleHAiOjE3Nzg3NDE0OTF9.ZVu_k5nF_yUdykTQyqmm73Zso4rax6fcIRw21KUtoJo", // Auth Header here
        //   },
        // });
        // client.activate();
        // console.log("sending message 2............................")
        const typeMessage = message?.parts[0]?.type;
        let msg;
        let status;
        if(typeMessage=="text"){
          msg = message?.parts[0]?.text;
          
        }
     
        const  chatUserRec:Record<string,string> = {
          [receiver.id]:receiverName,
          [AppUser?.id]:AppUser?.name
        }

        const chatConversationDTO:ChatConversationDTO = getChatConversationDTO(String(message.conversationId),chatUserRec,AppUser?.name,msg?msg:"")
        const  chatMessageUser:AppChatMessage = getChatMessageUser(message.id,String(message.conversationId),AppUser.id,msg?msg:"",status?status:"",AppUser?.name);
        console.log("sending started............");
        const type = message?.parts[0]?.type;
        if(appStompClient.current.connected){
          console.log(appStompClient.current.connected)
        }else{
          console.log("not connected")
          const m = message?.parts[0][type as keyof ChatMessagePart];
          console.log("adding message to setMessagesQueue here e ee e e e ")
          setMessagesQueue((prev) => [...prev,{chatMessageUser:chatMessageUser,chatConversationDTO:chatConversationDTO}]);
        }
      //    setThreads(Object.fromEntries(
      //   Object.entries(initialThreads).map(([id, msgs]) => [
      //     id,
      //     msgs.map((m) => ({ ...m })),
      //   ]),
      // ));
    

        //dispatch(changeTestState(message?.parts[0][type as keyof ChatMessagePart]))
       

    //  threads[fixTestsId].push( makeUserMessage('ac-ft-msg-900', fixTestsId, '2026-03-25T09:21:00.000Z', message?.parts[0][type as keyof ChatMessagePart]
    //   ,youUser));
    
    //  / dispatch(addToThreads(threads));
    
        //PUBLISH MESSAGE
        const headers = { Authorization: "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrYXNhbjA1MDZAcHJvdG9uLm1lIiwiaWF0IjoxNzgyNjIzNjU0LCJleHAiOjE3ODI2MjcyNTR9.ITMNw2EqtOIxA9u46bwUC8Ins0bPQJGYTf1Z3fIXj_s",'content-type': 'application/json' };
        const dummyId="aedca47d-9f9a-4cc4-a87f-a02651c71b5a";
        console.log("when publisjing new message started jjsdsaj dsjkdjksdjksjkdskjdskdsjkdskdjskj............")
       
        //getChatMessageUser()

        //console.log(conversations.filter(c=>c.id===activeId))
        console.log(chatConversationDTO);
        console.log(chatMessageUser);
        console.log("receiver.id"+"  "+receiver.id)
        console.log("when publisjing new............")

        if (appStompClient.current && appStompClient.current.connected) {
            appStompClient.current.publish({
              destination: '/app/chat/'+receiver.id,
              headers: headers, 
              body: JSON.stringify({ chatMessage:chatMessageUser,chatConversationDTO:chatConversationDTO }),
          });

          // threads[fixTestsId].push( makeAssistantMessage('ac-ft-msg-9', fixTestsId, '2026-03-25T09:21:00.000Z', [
          //   {
          //     type: 'text',
          //     text: "I have enogh time to chat with you",
          //     state: 'done',
          //   },
          // ]));
          // setThreads(threads);
          console.log("sending progress............ destination: '/app/chat/'"+receiver.id)
        }
        return new ReadableStream({
          start(controller) {
            controller.close();
          },
        });
         
      },
    });
    const token = "";
    const adapter :ChatAdapter=  createWebSocketAdapter(token);
    // const adapter :ChatAdapter= {
    //   async sendMessage({ message, signal }):Promise<any> {
    //     console.log(message)
    //     const res = await fetch('http://localhost:8080/app/chat/2', {
    //       method: 'POST',
    //       body: JSON.stringify({ message }),
    //       signal,
    //     });
     
    //     return res.body!;
    //   },
    //   subscribe({ onEvent }) {
    //     const ws = new WebSocket('http://localhost:8080/ws/topic/message/2');
    //     ws.onmessage = (e) => onEvent(JSON.parse(e.data));
    //     return () => ws.close(); // cleanup on unmount


    //   },
    
    //   async setTyping({ conversationId, isTyping }) {
    //     await fetch('/api/typing', {
    //       method: 'POST',
    //       body: JSON.stringify({ conversationId, isTyping }),
    //     });
    //   },
    
    //   async markRead({ conversationId, messageId }) {
    //     await fetch('/api/read', {
    //       method: 'POST',
    //       body: JSON.stringify({ conversationId, messageId }),
    //     });
    //   },
    // }


    let counter = 0;
    //  function createEchoAdapter(
    //     options: {
    //       agent?: ChatUser;
    //       delayMs?: number;
    //       respond?: (text: string) => string;
    //     } = {},
    //   ): ChatAdapter {
    //     console.log(options);
    //     const { agent } = options;
    //     const agentName = agent?.displayName ?? 'KasanAssistant';
        
    //     const delayMs = options.delayMs ?? 170;
    //     const respond =
    //       options.respond ??
    //       ((text: string) =>
    //         `${agentName} received "${text}". Kasan UI styles applied automatically from the active theme.`);
      
    //     return {
    //       async sendMessage({ message }) {
    //         const textOnly = message.parts
    //           .map((part) => (part.type === 'text' ? part.text : null))
    //           .filter(Boolean)
    //           .join('\n');
    //         const responseText = respond(textOnly || getMessageText(message));
      
    //         return createChunkStream(
    //           createTextResponseChunks(randomId(), responseText, agent ? { author: agent } : undefined),
    //           { delayMs },
    //         );
    //       },
    //     };
    //   }
     

      const messages = threads[activeId] ?? [];
       function getMessageText(message: ChatMessage) {
        return message.parts
          .map((part) => {
            if (part.type === 'text' || part.type === 'reasoning') {
              return part.text;
            }
      
            if (part.type === 'file') {
              return part.filename ?? part.url;
            }
      
            return JSON.stringify(part);
          })
          .join('\n');
      }

       function createChunkStream(
        chunks: Array<ChatMessageChunk | ChatStreamEnvelope>,
        options: { delayMs?: number } = {},
      ) {
        const { delayMs = 170 } = options;
      
        return new ReadableStream<ChatMessageChunk | ChatStreamEnvelope>({
          start(controller) {
            let didFinish = false;
      
            chunks.forEach((chunk, index) => {
              setTimeout(
                () => {
                  if (didFinish) {
                    return;
                  }
      
                  controller.enqueue(chunk);
      
                  if (index === chunks.length - 1) {
                    didFinish = true;
                    controller.close();
                  }
                },
                delayMs * (index + 1),
              );
            });
          },
        });
      }

      //  function createTextResponseChunks(
      //   messageId: string,
      //   text: string,
      //   options?: { finishReason?: string; author?: ChatUser },
      // ): ChatMessageChunk[] {
      //   const finishReason = options?.finishReason ?? 'stop';
      //   const partId = `${messageId}-text`;
      
      //   return [
      //     { type: 'start', messageId, ...(options?.author ? { author: options.author } : undefined) },
      //     { type: 'text-start', id: partId },
      //     ...splitText(text).map(
      //       (delta) =>
      //         ({
      //           type: 'text-delta',
      //           id: partId,
      //           delta,
      //         }) satisfies ChatMessageChunk,
      //     ),
      //     { type: 'text-end', id: partId },
      //     { type: 'finish', messageId, finishReason },
      //   ];
      // }
       function splitText(text: string, size = 18) {
        const chunks: string[] = [];
      
        for (let index = 0; index < text.length; index += size) {
          chunks.push(text.slice(index, index + size));
        }
      
        return chunks.length === 0 ? [''] : chunks;
      }
       function randomId(): string {
        if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
          return crypto.randomUUID();
        }
      
        counter += 1;
        return `${Date.now().toString(36)}-${counter.toString(36)}`;
      }

       function syncConversationPreview(
        conversations: ChatConversation[],
        conversationId: string,
        messages: ChatMessage[],
      ) {
        const lastMessage = messages[messages.length - 1];
        const preview =
          lastMessage == null ? undefined : getMessageText(lastMessage).split('\n')[0]?.slice(0, 70);
      
        return conversations.map((conversation) => {
          if (conversation.id !== conversationId) {
            return conversation;
          }
          return {
            ...conversation,
            subtitle: preview ?? conversation.subtitle,
            lastMessageAt: lastMessage?.createdAt ?? conversation.lastMessageAt,
          };
        });
      }
      const sendNewPerson = ()=>{
        setEnableSearch(true);
        dispatch(loadFriends())
      }
      // const isMounted = useRef(false);
      // useEffect(()=>{
      //   if (!isMounted.current) {
      //     console.log("thraesd catcher.............");
      //   console.log(threads);
      //   console.log("thraesd catcher.............");
      //     isMounted.current = true; // Mark as mounted
      //     return; // Skip execution on initial mount
      //   }
        
      // },
      // [conIdRecords,threads])
      const onPersChange = useCallback((e:React.SyntheticEvent,person:any)=>{
        console.log("onPersChange excuyererenrenrenrbenrberbernenbr")
        console.log(person)
        console.log("onPersChange excuyererenrenrenrbenrberbernenbr")
        const matchMakerSearchProfile:MatchMakerSearchProfile = person?.friend
        setReceiver((prevF)=>{
          return {...prevF,id:matchMakerSearchProfile.id,name:matchMakerSearchProfile.name}
        })
        setReceiverName(matchMakerSearchProfile?.name);
        
        let conId1:string;
        conId1 = crypto.randomUUID().toString();
       
        const existsConversations = conversations.find(c=>(Number(c.participants?.[0]?.id)===Number(matchMakerSearchProfile?.id)) ||
          (Number(c.participants?.[1]?.id) === Number(matchMakerSearchProfile?.id))
        );
        if(existsConversations){
          setActiveId(existsConversations?.id);
           setEnableSearch(false);
           const p:ChatUser[] =existsConversations?.participants??[];
           if(p){
            if(String(p?.[0]?.id)===String(matchMakerSearchProfile.id)){
              setActiveUserOnline(p?.[0]?.isOnline)
            }else{
              setActiveUserOnline(p?.[1]?.isOnline)
            }
           }
          
          return;
        }
        const aUser:ChatUser ={
          id: matchMakerSearchProfile?.id,
          displayName: matchMakerSearchProfile?.name,
          avatarUrl: createAvatarDataUrl(matchMakerSearchProfile?.name?matchMakerSearchProfile?.name?.charAt(0).toUpperCase():"Y", '#B82C16'),
          isOnline: true,
        }
        const cUser:ChatUser = {
          id: AppUser.id,
          displayName: AppUser.name,
          avatarUrl: createAvatarDataUrl(AppUser.name[0].toUpperCase(), '#F227F5'),
          isOnline: true,
        };
         if(person){
          const arr:ChatConversation[] =  [{
                    id: conId1,
                    title: matchMakerSearchProfile?.name,
                    subtitle: '',
                    participants: [aUser,cUser],
                    readState: 'unread',
                    unreadCount: 0,
                    lastMessageAt: '2026-03-21T09:30:00.000Z',//new Date().toISOString()
                  }];         
          setConversations((prevCon)=>{
            if(!prevCon || prevCon.length==0) return arr;
            return [...prevCon,...arr]
          })
          setConversationClicked(true);
         setEnableSearch(false);
         setActiveId(conId1);
         }
      
        setThreads((prevState)=>{
          const existingMessages = prevState[conId1] ?? [];
          return {
            ...prevState,
            [conId1]: [...existingMessages],
          };
        })
      },[conIdRecords,receiver,conversations,threads,activeId])
      useEffect(()=>{
        console.log("Receiver id has changed latest record forunf syateme jssdjhsdjsdjsjdsjdsdjfjdhf")
      
        if(userFromAnotherTabId && userFromAnotherTabName){
          const fakeEvent = {
          } as unknown as React.ChangeEvent<HTMLInputElement>;
          onPersChange(fakeEvent,{friend:{
            id:userFromAnotherTabId,
            name:userFromAnotherTabName
          }});
        }
        console.log("Receiver id has changed latest record forunf syateme jssdjhsdjsdjsjdsjdsdjfjdhf")

      },[userFromAnotherTabId,userFromAnotherTabName])
    return <ThemeProvider theme={theme}>
   <Box 
   sx={{paddingLeft:5,paddingRight:5,paddingBottom:5}}>
   <Stack sx={{p:2}} display={"flex"} flexDirection={"row"} >
   {enableSearch && <Autocomplete
      disablePortal
      options={prepareFriendList(friends)}
      sx={{ width:isMobile?"10em":"12em",border:"none",
        padding:2,
        '& .MuiOutlinedInput-root': {
          background:"#E3E1DE",
          borderRadius: '1em',
          // Custom pixels or percentage
        }, 
      }}
      onChange={onPersChange}
      renderInput={(params) => <TextField  variant="filled" {...params} label={<Typography variant="body2">Type For Friends</Typography>} />}
    />}
    <Button   startIcon={<AddIcon/>}  onClick={sendNewPerson} sx={{marginLeft:"auto"}}>Send New</Button>
   </Stack>
    <ChatBox
    slots={
      {
        conversationSubtitle:OnlineStatus
      }
    }
    conversations={conversations}
      adapter={adapter}
      messages={messages}
      initialActiveConversationId={minimalConversation.id}
     currentUser={currentUser}
     activeConversationId={activeId}
      sx={{
        m:1,
        height: 600,
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 1,
        '@media screen and (max-width: 601px)': {
          '& .MuiChatBox-conversationsPane': {
            display: conversationClicked ? 'none' : 'flex',
            width: '100%',
          },
          '& .MuiChatBox-threadPane': {
            display: conversationClicked ? 'flex' : 'none',
            width: '100%',
          }
        },
        '.MuiChatComposer-textArea': {
            visibility: !conversations || conversations.length==0?"hidden":"visible"
        }
      }}
      onClick={(e)=>{
        console.log(activeId)
      }}
      density={"standard"}
      onActiveConversationChange={(nextId) => {
        console.log(nextId)
        const participantsArr:ChatUser[]= conversations
        .filter(c=>c.id===nextId)
        .flatMap(c=>c.participants?c.participants:[])
        if(String(AppUser.id) === String(participantsArr[0]?.id)){
          setReceiver((prevF)=>({...prevF,id:participantsArr[1]?.id,name:participantsArr[1]?.displayName?participantsArr[1]?.displayName:""}))
          setReceiverName(participantsArr[1]?.displayName?participantsArr[1]?.displayName:"");
          setActiveUserOnline(participantsArr[1]?.isOnline);
        }else{
          setReceiver((prevF)=>({...prevF,id:participantsArr[0]?.id,name:participantsArr[0]?.displayName?participantsArr[0]?.displayName:""}))
          setReceiverName(participantsArr[0]?.displayName?participantsArr[0]?.displayName:"");
          setActiveUserOnline(participantsArr[0]?.isOnline);
        }
        if (nextId) {
          setActiveId(nextId);
        }
      }}
      slotProps={{
        conversationList: {
          onClick: () => setConversationClicked(true),
        },
        threadPane: {
          onClick: () => setConversationClicked(false)
        },
        conversationSubtitle: {
          // If TypeScript still complains, cast via unknown or define the interface properly
          onlineStatus: activeUserOnline,
        } as any, 
      }}
      onMessagesChange={(nextMessages) => {
        setThreads((prev) => ({ ...prev, [activeId]: nextMessages }));
        const participantsArr:ChatUser[]= conversations
        .filter(c=>c.id===activeId)
        .flatMap(c=>c.participants?c.participants:[])
        if(String(AppUser.id) === String(participantsArr[0]?.id)){
          setReceiver((prevF)=>({...prevF,id:participantsArr[1]?.id,name:participantsArr[1]?.displayName?participantsArr[1]?.displayName:""}))
          setReceiverName(participantsArr[1]?.displayName?participantsArr[1]?.displayName:"");
          setActiveUserOnline(participantsArr[1]?.isOnline);
        }else{
          setReceiver((prevF)=>({...prevF,id:participantsArr[0]?.id,name:participantsArr[0]?.displayName?participantsArr[0]?.displayName:""}))
          setReceiverName(participantsArr[0]?.displayName?participantsArr[0]?.displayName:"");
          setActiveUserOnline(participantsArr[0]?.isOnline);
        }
        setConversations((prev) =>
          syncConversationPreview(prev, activeId, nextMessages),
        );
      }}
    >
        </ChatBox></Box>
    </ThemeProvider>
}
export default ChatScreen;