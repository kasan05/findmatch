export  interface User {
      id: string;
      displayName: string;
      avatarUrl: string;
      isOnline: boolean;
      role?: string;
}