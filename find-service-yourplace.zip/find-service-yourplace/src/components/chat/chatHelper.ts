import type { ChatConversation, ChatMessage, ChatMessagePart, ChatUser } from "@mui/x-chat/core";
import mark from './mark.jpg';
import type { ChatConversationDTO } from "../../types/ChatConversationDTO";
import type { ChatUserDTO } from "../../types/ChatUserDTO";
import type { AppChatMessage } from "../../types/AppChatMessage";
import type { ChatTextMessagePart } from "../../types/ChatTextMessagePart";

export function makeUserMessage(
    id: string,
    conversationId: string,
    text: string,
    createdAt: string,
    author:ChatUser,
  ): ChatMessage {
    return {
      id,
      conversationId,
      role: 'user',
      status: 'sent',
      createdAt,
      author: author,
      parts: [{ type: 'text', text }],
    };
  }
  
  function makeAssistantMessage(
    id: string,
    conversationId: string,
    createdAt: string,
    parts: ChatMessagePart[],
    status: ChatMessage['status'] = 'sent',
    author:ChatUser
  ): ChatMessage {
    return {
      id,
      conversationId,
      role: 'assistant',
      status,
      createdAt,
      author: author,
      parts,
    };
  }

  function createAvatarDataUrl(
    label: string,
    background: string,
    foreground = '#ffffff',
  ) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="24" fill="${background}"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" font-family="Arial, sans-serif" font-size="28" font-weight="600" fill="${foreground}">${label}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

const youUser:ChatUser = {
    id: 'you',
    displayName: 'You',
    avatarUrl: createAvatarDataUrl('Y', '#1976d2'),
    isOnline: true,
  };
  const fixTestsIdUser:ChatUser = {
    id: 'fixTestsIdUser',
    displayName: 'fixTestsIdUser',
    avatarUrl: createAvatarDataUrl('Y', '#1976d2'),
    isOnline: true,
  };
  const addFeatureIdUser:ChatUser = {
    id: 'addFeatureIdUser',
    displayName: 'addFeatureIdUser',
    avatarUrl: mark,
    isOnline: true,
  };
  const dangerousCmdIdUser:ChatUser = {
    id: 'dangerousCmdIdUser',
    displayName: 'dangerousCmdIdUser',
    avatarUrl: createAvatarDataUrl('Y', '#1976d2'),
    isOnline: true,
  };
  export function getInitialThreads(fixTestsId:string,addFeatureId:string,dangerousCmdId:string): Record<string, ChatMessage[]> {
return {}
// return {
  
//     [fixTestsId]: [
//       makeUserMessage(
//         'ac-ft-msg-1',
//         fixTestsId,
//         'The unit tests are failing after the recent refactor. Can you fix them?',
//         '2026-03-21T09:20:00.000Z',
//         youUser
//       ),
//       makeAssistantMessage('ac-ft-msg-2', fixTestsId, '2026-03-21T09:21:00.000Z',[
//         { type: 'step-start' },
//         {
//           type: 'reasoning',
//           text: 'I need to locate the failing test files and trace which imports changed during the refactor. The error is most likely a path issue — components were probably moved to a subdirectory.',
//           state: 'done',
//         },
//         {
//           type: 'text',
//           text: "I'll start by locating all test files in the project.",
//           state: 'done',
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-ft-tc-1',
//             toolName: 'glob',
//             state: 'output-available',
//             input: { pattern: 'src/**/*.test.ts' },
//             output: {
//               files: ['src/Button.test.ts', 'src/Input.test.ts', 'src/Form.test.ts'],
//             },
//           },
//         },
//         {
//           type: 'text',
//           text: 'Found 3 test files. Reading the one with the broken imports…',
//           state: 'done',
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-ft-tc-2',
//             toolName: 'read_file',
//             state: 'output-available',
//             input: { path: 'src/Button.test.ts' },
//             output: {
//               content:
//                 "import { Button } from './Button';\nimport { render } from '@testing-library/react';\n\ntest('renders', () => render(<Button>Click</Button>));",
//             },
//           },
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-ft-tc-3',
//             toolName: 'edit_file',
//             state: 'output-available',
//             input: {
//               path: 'src/Button.test.ts',
//               old_str: "import { Button } from './Button'",
//               new_str: "import { Button } from '../components/Button'",
//             },
//             output: { patched: true },
//           },
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-ft-tc-4',
//             toolName: 'bash',
//             state: 'output-available',
//             input: { command: 'pnpm test --run' },
//             output: {
//               stdout:
//                 '✓ Button.test.ts (3)\n✓ Input.test.ts (5)\n✓ Form.test.ts (2)\n\nAll tests passed.',
//               exit_code: 0,
//             },
//           },
//         },
//         {
//           type: 'text',
//           text: 'All 3 test files are now passing. The import path was wrong after the refactor — components moved from `src/` to `src/components/`.',
//           state: 'done',
//         },
//       ],'sent',fixTestsIdUser),
//     ],
  
//     [addFeatureId]: [
//       makeUserMessage(
//         'ac-af-msg-1',
//         addFeatureId,
//         'Add a dark mode toggle button to the header',
//         '2026-03-21T08:00:00.000Z',
//         youUser
//       ),
//       makeAssistantMessage('ac-af-msg-2', addFeatureId, '2026-03-21T08:01:00.000Z', [
//         { type: 'step-start' },
//         {
//           type: 'reasoning',
//           text: "I should read the existing Header component before adding anything, so I can see how it's structured and where to place the toggle.",
//           state: 'done',
//         },
//         {
//           type: 'text',
//           text: 'Let me read the Header component first.',
//           state: 'done',
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-af-tc-1',
//             toolName: 'read_file',
//             state: 'output-available',
//             input: { path: 'src/components/Header.tsx' },
//             output: {
//               content:
//                 "import AppBar from '@mui/material/AppBar';\nimport Toolbar from '@mui/material/Toolbar';\nimport Typography from '@mui/material/Typography';\n\nexport function Header() {\n  return (\n    <AppBar position=\"static\">\n      <Toolbar>\n        <Typography variant=\"h6\">My App</Typography>\n      </Toolbar>\n    </AppBar>\n  );\n}",
//             },
//           },
//         },
//         {
//           type: 'text',
//           text: "Now I'll create the DarkModeToggle component.",
//           state: 'done',
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-af-tc-2',
//             toolName: 'write_file',
//             state: 'output-available',
//             input: {
//               path: 'src/components/DarkModeToggle.tsx',
//               content:
//                 "import * as React from 'react';\nimport IconButton from '@mui/material/IconButton';\n\nexport function DarkModeToggle({ mode, onToggle }: { mode: 'light' | 'dark'; onToggle(): void }) {\n  return (\n    <IconButton color=\"inherit\" onClick={onToggle} aria-label=\"toggle dark mode\">\n      {mode === 'dark' ? '☀️' : '🌙'}\n    </IconButton>\n  );\n}",
//             },
//             output: { written: true, bytes: 612 },
//           },
//         },
//         {
//           type: 'dynamic-tool',
//           toolInvocation: {
//             toolCallId: 'ac-af-tc-3',
//             toolName: 'bash',
//             state: 'output-available',
//             input: { command: 'pnpm build' },
//             output: {
//               stdout: 'Build successful. 3 modules compiled in 1.2s.',
//               exit_code: 0,
//             },
//           },
//         },
//         {
//           type: 'text',
//           text: '`DarkModeToggle.tsx` is created and the build passes. Import it in `Header.tsx` and pass `mode` + `onToggle` from your theme context.',
//           state: 'done',
//         },
//       ],'sent',addFeatureIdUser),
//     ],
  
//     [dangerousCmdId]: [
//       makeUserMessage(
//         'ac-dc-msg-1',
//         dangerousCmdId,
//         'Clean up all build artifacts and reset to a clean state',
//         '2026-03-21T10:00:00.000Z',
//         youUser
//       ),
//       makeAssistantMessage(
//         'ac-dc-msg-2',
//         dangerousCmdId,
//         '2026-03-21T10:01:00.000Z',
//         [
//           { type: 'step-start' },
//           {
//             type: 'text',
//             text: "I'll run a cleanup command. This will permanently delete build output and untracked files — please confirm before I proceed.",
//             state: 'done',
//           },
//           {
//             type: 'dynamic-tool',
//             toolInvocation: {
//               toolCallId: 'ac-dc-tc-1',
//               toolName: 'bash',
//               state: 'approval-requested',
//               input: { command: 'rm -rf ./dist ./coverage && git clean -fd' },
//             },
//           },
//         ],
//         'sent',dangerousCmdIdUser
//       ),
//     ],
//   };
//   }
}

  export function getInitialConversations(fixTestsId:string,addFeatureId:string,dangerousCmdId:string
  ):ChatConversation[] {
   
      return  [
          {
              id: fixTestsId,
              title: 'fixTestsId Messages',
              subtitle: 'pnpm test: 3 failing',
              participants: [youUser, fixTestsIdUser],
              readState: 'read',
              unreadCount: 0,
              lastMessageAt: '2026-03-21T09:30:00.000Z',
            },
            {
              id: addFeatureId,
              title: 'addFeatureId messages',
              subtitle: 'New component created',
              participants: [youUser, addFeatureIdUser],
              readState: 'read',
              unreadCount: 0,
              lastMessageAt: '2026-03-21T08:15:00.000Z',
            },
            {
              id: dangerousCmdId,
              title: 'dangerousCmdId messages',
              subtitle: 'Awaiting your approval…',
              participants: [youUser, dangerousCmdIdUser],
              readState: 'unread',
              unreadCount: 1,
              lastMessageAt: '2026-03-21T10:05:00.000Z',
            }
      ]
  }
  export function getChatConversationDTO(conversationId:string,chatUserRec:Record<string,string>,author:string,message:string):ChatConversationDTO{
    const participants:Array<ChatUserDTO> = Object.entries(chatUserRec).map(([id,name])=>{
      return{
        id: id,
      displayName: name,
      isOnline: false
      }
    })
    return {
      id:conversationId,
      title:author,
      subtitle:message,
      participants:participants,
      readState:"",
      unreadCount:0,
      lastMessageAt:new Date().toISOString()
    }
  }
  export function getChatMessageUser(chatMessageId:string,conversationId:string,userId:string,message:string,status:string,userName:string):AppChatMessage{
    const chatUser:ChatUserDTO ={
      id: userId,
      displayName:userName,
      isOnline: false
  }
  const part:ChatTextMessagePart = {
    type: "text",
    text: message,
    state: status //"streaming"  
  }
    return{
      id:chatMessageId,
      conversationId:conversationId,
      role:"user",
      status: status,
      createdAt:new Date().toISOString(),
      author:chatUser,
      parts:[part]
    }
  }
  export function getChatMessageAssistant(chatMessageId:string,conversationId:string,userId:string,message:string,status:string,userName:string):AppChatMessage{
    const chatUser:ChatUserDTO ={
      id: userId,
      displayName: userName,
      isOnline: false
  }
  const part:ChatTextMessagePart = {
    type: "text",
    text: message,
    state: status //"streaming" |
  }
    return{
      id:chatMessageId,
      conversationId:conversationId,
      role:"assistant",
      status: status,
      createdAt:new Date().toISOString(),
      author:chatUser,
      parts:[part]
    }
  }
  export function stringToHexColor(str:string) {
    if(!str){return "#1976d2";}
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = '#';
    for (let i = 0; i < 3; i++) {
      const value = (hash >> (i * 8)) & 0xFF;
      color += ('00' + value.toString(16)).slice(-2);
    }
    return color;
  }