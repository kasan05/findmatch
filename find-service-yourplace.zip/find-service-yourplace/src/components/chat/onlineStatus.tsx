import { Badge, Box, Stack, Typography, type TypographyProps } from "@mui/material";

interface OnlineStatusSubtitleProps extends TypographyProps {
    onlineStatus?: boolean;
  }
  
const OnlineStatus = ({ onlineStatus, children, ...props }: OnlineStatusSubtitleProps)=>{

    return (
        <Stack flexDirection={"row"} display={"flex"} justifyContent={"center"} alignItems={"center"} gap={1}>
        <Typography variant="caption" {...props}>
          {onlineStatus ? 'Online' : 'Offline'} {children}   </Typography>
          <Box
      sx={{
        width: 10,
        height: 10,
        borderRadius: '100%',
        bgcolor: onlineStatus?"green":"red",
      }}
    />
       
        </Stack>
      );

}
export default OnlineStatus;