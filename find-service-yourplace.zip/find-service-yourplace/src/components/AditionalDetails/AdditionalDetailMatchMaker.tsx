import { Alert, Avatar, Box, Button, Card, CardContent, CardHeader, Container, FormControl, Grid, IconButton, ImageList, ImageListItem, ImageListItemBar, InputLabel, LinearProgress, MenuItem, Select, Stack, TextField, Typography, useMediaQuery, type SelectChangeEvent } from "@mui/material";
import { useActionState, useEffect, useRef, useState } from "react";
import InfoIcon from '@mui/icons-material/Info';
import { PhotoAlbum } from "@mui/icons-material";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { addAditionalDetailsToMatchMaker, loadPersonnelData } from "../../store/matchmakerSlice";
import { useNavigate } from "react-router-dom";

const AdditionalDetailMatchMaker = ()=>{
  const isMobile = useMediaQuery(theme=>theme.breakpoints.down("sm"));
  const [professionErr,setProfessionErr] = useState<boolean>(false);
  const[casteErr,setCasteErr] = useState<boolean>(false);
  const [profession,setProfession] = useState<string>();
  const [caste,setCaste] = useState<string>();
  const [gender,setGender] = useState<string>();
  const [maritalStatus,setMaritalStatus] = useState<string>();
  const [genderErr,setGenderErr] = useState<boolean>(false);
  const [maritalStatusErr,setMaritalStatusErr] = useState<boolean>(false);  
  const [countryErr,setCountryErr] = useState<boolean>(false);
  const [religionErr,setReligionErr] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [religionselectopen, setReligionselectopen] = useState(false);
  const [casteselectopen, setCasteselectopen] = useState(false);
  const [professionselectopen, setProfessionselectopen] = useState(false);
  const [genderselectopen, setGenderselectopen] = useState(false);
  const [maritalStatusselectopen, setMaritalStatusselectopen] = useState(false);
  const [religion, setReligion] = useState<string>('');
  const [countryselectopen, setCountryselectopen] = useState(false);
  const [country, setCountry] = useState<string>('');
  const[fileArray,setFileArray] = useState<File[]|null>(null);
  const [page,setPage]=useState<number>(0);
  const[isFileArrayLengthThree,setIsFileArrayLengthThree] = useState<boolean>(false);
  const [state,additionalDetailsFormAction,isPending] = useActionState(submitAdditionalDetails,{success:false,message:""});
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const castesArray = useAppSelector(state=>state.matchMaker.castes);
  const genders = useAppSelector(state=>state.matchMaker.genders);
  const maritalStatuses = useAppSelector(state=>state.matchMaker.maritalStatuses);
  const religions = useAppSelector(state=>state.matchMaker.religions);
  const countries = useAppSelector(state=>state.matchMaker.countries);
  const professions = useAppSelector(state=>state.matchMaker.professions);
  const loading = useAppSelector(state=>state.matchMaker.loading);


  type FormDataState = {
    message?: string | null;
    errors?: Record<string, string[] | undefined>;
    success?: boolean;
  } | undefined
  async function submitAdditionalDetails(prevState:FormDataState,formData:FormData){
    
    const data = new FormData()
    data.append("caste",caste??"");
    data.append("gender",gender??"");
    data.append("maritalStatus",maritalStatus??"");
    data.append("profession",profession??"");
    data.append("country",country??"");
    data.append("religion",religion??"");
    
    // if(fileArray){
    //   data.append("multipartFile",fileArray[0]);
    // }
   
     fileArray && fileArray.forEach(file=>{
        data.append("multipartFiles",file);
      })
  
   try{
    console.log("doing heree hjdhsjdhjsdjsdsdjsdsdsdjsdjsdsjhdjhsdjh")
    dispatch(addAditionalDetailsToMatchMaker(data)).unwrap()
    .then((result)=>{
      console.log("response .....")
            console.log(result)
            console.log("response .....")
            console.log("redirect  /match-maker/profile")
      navigate("/match-maker/profile")
    }).catch(e=>{
      console.log("inside errrrrrrrrrrrrrrrrrrr")
      console.log(e)
      // setFileArray([]);
      // setReligion("");
      // setCaste("");
      // setCountry("");
      // setProfession("");
      // setPage(0);
      navigate("/match-maker/additional-details")
      return {success:false,message:""}
    })
   }catch(e){
    console.log("outside")
    console.log(e)
    // setFileArray([]);
    // setReligion("");
    // setCaste("");
    // setCountry("");
    // setProfession("");
    // setPage(0);
     navigate("/match-maker/additional-details")
      return {success:false,message:""}
   }

    return {success:false,message:""}
  }
    const onChangeProfession = (e:React.ChangeEvent<HTMLInputElement>)=>{
      const prof = e.target.value;
      if(prof && prof.trim().length>0){
        setProfessionErr(false);
      }
      setProfession(prof);
    }
    const onChangeCaste = (e:React.ChangeEvent<HTMLInputElement>) =>{
      const cas = e.target.value;
      if(cas && cas.trim().length>0){
        setCasteErr(false);
      }
      setCaste(e.target.value);
    }
    const onImageFileUpload = (event:React.ChangeEvent<HTMLInputElement>)=>{
      if(fileArray && fileArray.length==3)return;
      console.log("onImageFileUpload func")
      const files:FileList| null= event.target.files;
      if(files){
        const f:File[] = Array.from(files);
        const nArray:File[] = [];
          setFileArray((prevFiles)=>{
            if(prevFiles){
                prevFiles.forEach((pFile)=>{
                  const isDup = f.some((fS)=>fS.name === pFile.name && pFile.size === fS.size);
                  if(!isDup){
                    nArray.push(pFile);
                  }
                })
              return [...f.slice(0,3-nArray.length),... nArray];
            }else{
              return [...f.slice(0, 3)];
            }
          });
        
      }
    }
    useEffect(()=>{
      console.log("fileArray length");
      console.log(fileArray?.length);
      if(fileArray && fileArray?.length==3){
        setIsFileArrayLengthThree(true);
      }else{
        setIsFileArrayLengthThree(false);
      }
    },[fileArray])

    useEffect(()=>{
      dispatch(loadPersonnelData()).unwrap().catch(e=>{
        console.log("redrect to login")
        navigate("/login");
      })
    },[dispatch])

    const handleCountryClose = () => {
        setCountryselectopen(false);
      };
    
      const handleCountryOpen = () => {
        setCountryselectopen(true);
      };
      const handleCountryChange = (e:SelectChangeEvent<typeof religion>)=>{
        setCountry(e.target.value);
        setCountryErr(false);
      }
      const handleReligionClose = () => {
        setReligionselectopen(false);
      };
    
      const handleReligionOpen = () => {
        setReligionselectopen(true);
      };
      const handleReligionChange = (e:SelectChangeEvent<typeof religion>)=>{
        setReligion(e.target.value);
        setReligionErr(false);
      }
      const handleCasteClose = () => {
        setCasteselectopen(false);
      };
    
      const handleCasteOpen = () => {
        setCasteselectopen(true);
      };
      const handleCasteChange = (e:SelectChangeEvent<typeof religion>)=>{
        setCaste(e.target.value)
        setCasteErr(false);
      }
      const handleProfessionClose = () => {
        setProfessionselectopen(false);
      };
    
      const handleProfessionOpen = () => {
        setProfessionselectopen(true);
      };
      const handleProfessionChange = (e:SelectChangeEvent<typeof religion>)=>{
        setProfession(e.target.value)
        setProfessionErr(false);
      }
      const handleMaritalStatusChange = (e:SelectChangeEvent<typeof religion>)=>{
        setMaritalStatus(e.target.value)
        setMaritalStatusErr(false);
      }
      const handleMaritalStatusClose = () => {
        setMaritalStatusselectopen(false);
      };
    
      const handleMaritalStatusOpen = () => {
        setMaritalStatusselectopen(true);
      };
      const handleGenderChange = (e:SelectChangeEvent<typeof religion>)=>{
        setGender(e.target.value)
        setGenderErr(false);
      }
      const handleGenderClose = () => {
        setGenderselectopen(false);
      };
    
      const handleGenderOpen = () => {
        setGenderselectopen(true);
      };
      const handleClick=()=>{
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
          fileInputRef.current?.click();
        }
      }
      const handleSubmit = ()=>{
        console.log(profession);
        console.log(caste);
        console.log(country);
        console.log(religion);
        console.log(fileArray);
        
      }
      const handleDeleteImage = (file:File)=>{
        setFileArray((prevFiles)=>{
          if(prevFiles){
            return [...prevFiles.filter((pF)=>!(pF.name==file.name && file.size==pF.size))];
          }else{
            return fileArray;
          }
        })
      }
      const onNext = ()=>{
        if(!gender){
          setGenderErr(true);
          return;
        } if(!maritalStatus){
          setMaritalStatusErr(true);
          return;
        }
        if(!profession){
          setProfessionErr(true);
          return;
        }
        if(!caste){
          setCasteErr(true);
          return;
        }
        if(!country){
          setCountryErr(true);
          return;
        }
        if(!religion){
          setReligionErr(true);
          return;
        }
        setPage(1);
      }
    return (<>{loading?(<div style={
          {
            color:"#ADD8E6",
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)', // Offsets the bar's own height/width to be perfectly centered
           zIndex:1
          }
        }>
    <Box sx={{ width: 100 ,display:"flex",flexDirection:"column",gap:1,color:"#ADD8E6"}}>
    <Typography  sx={{fontSize:{fontWeight:"500"}}}>FindUrMatch</Typography>
      <LinearProgress   />
    </Box>
    
        </div>) :(<Container sx={{marginTop:10,marginBottom:5}}>
        <Box sx={{
        display:"flex",
        width:"100%",
        flexDirection:"column",
        placeItems:"center",
       height:"100vh"
    }}>
    <Box sx={{ width:isMobile?"100%":"50%", display:"flex", flexDirection:"column",
        placeItems:"center",
        paddingBottom:"10vh"}}>
    <Card sx={{width:"100%"}}>
    <CardHeader title={
          <Stack direction={"row"} spacing={1} justifyContent={"center"} alignItems={"center"}>
          <Avatar sx={{background:"#ADD8E6",fontWeight:"500"}}><InfoIcon/></Avatar>
          <Typography sx={{fontSize:{xs:'0.8rem',md:'0.9rem'}}}>{page==0?"ADDITIONAL DETAILS":"PHOTO ALBUMN"}</Typography>
          </Stack>
        } />
    <CardContent>
    {page==0 &&<>
      <FormControl  sx={{mb:3}} fullWidth>
    <InputLabel  id="demo-controlled-open-select-label">Gender</InputLabel>
    <Select
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={genderselectopen}
          onClose={handleGenderClose}
          onOpen={handleGenderOpen}
          value={gender}
          label="Gender"
          error={genderErr}
          onChange={handleGenderChange}
        >
{genders && genders.map(g=>((<MenuItem value={g.toString()} key={g.toString()}>{g}</MenuItem>)))}
        </Select>
    </FormControl>
    <FormControl  sx={{mb:3}} fullWidth>
    <InputLabel  id="demo-controlled-open-select-label">MaritalStatus</InputLabel>
    <Select
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={maritalStatusselectopen}
          onClose={handleMaritalStatusClose}
          onOpen={handleMaritalStatusOpen}
          value={maritalStatus}
          label="MaritalStatus"
          error={maritalStatusErr}
          onChange={handleMaritalStatusChange}
        >
{maritalStatuses && maritalStatuses.map(mStatus=>((<MenuItem value={mStatus.toString()} key={mStatus.toString()}>{mStatus}</MenuItem>)))}
        </Select>
    </FormControl>
    <FormControl  sx={{mb:3}} fullWidth>
    <InputLabel  id="demo-controlled-open-select-label">Profession</InputLabel>
    <Select
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={professionselectopen}
          onClose={handleProfessionClose}
          onOpen={handleProfessionOpen}
          value={profession}
          label="Profession"
          error={professionErr}
          onChange={handleProfessionChange}
        >
{professions && professions.map(prof=>((<MenuItem value={prof.toString()} key={prof.toString()}>{prof}</MenuItem>)))}
        </Select>
    </FormControl>
    <FormControl  sx={{mb:3}} fullWidth>
    <InputLabel id="demo-controlled-open-select-label">Caste</InputLabel>
    <Select
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={casteselectopen}
          onClose={handleCasteClose}
          onOpen={handleCasteOpen}
          value={caste}
          label="Caste"
          error={casteErr}
          onChange={handleCasteChange}
        >
          {castesArray && castesArray.map(c=>((<MenuItem value={c.toString()} key={c.toString()}>{c}</MenuItem>)))}
        </Select>
        </FormControl>
    <FormControl  sx={{mb:3}} fullWidth>
    <InputLabel id="demo-controlled-open-select-label">Country</InputLabel>
    <Select
    
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={countryselectopen}
          onClose={handleCountryClose}
          onOpen={handleCountryOpen}
          value={country}
          label="Country"
          error={countryErr}
          onChange={handleCountryChange}
        >
          {countries && countries.map(country=>(<MenuItem value={country.toString()} key={country.toString()}>{country}</MenuItem>))}
          
    </Select>
    </FormControl>
    <FormControl fullWidth>
    <InputLabel id="demo-controlled-open-select-label">Religion</InputLabel>
    <Select
    
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={religionselectopen}
          onClose={handleReligionClose}
          onOpen={handleReligionOpen}
          value={religion}
          label="Religion"
          error={religionErr}
          onChange={handleReligionChange}
        >
          {religions && religions.map(religion=>(<MenuItem value={religion.toString()}>{religion}</MenuItem>))}
         
    </Select>
    </FormControl>
    <Button sx={{mt:5}} variant="contained" onClick={onNext} fullWidth>NEXT</Button>
     </>}
    {page==1 && 
    <>
    <input ref={fileInputRef} name="passportFile" accept="image/*"  multiple style={{display:"none"}} onChange={onImageFileUpload} type="file"/>
    <Stack sx={{mt:2}} display={"flex"}  height="100%" direction={"column"} spacing={2} justifyContent={"center"} alignContent={"center"}>
      
      {fileArray?<ImageList   sx={{ width: "80vw", height: "100%",overflow:"hidden" }} cols={2}  gap={10} rowHeight={164}>
       { fileArray && fileArray.map((file:File)=>(
            <ImageListItem sx={{ objectFit: 'cover'}}>
              <img key={file.name} src={ URL.createObjectURL(file)} loading="lazy"/>
              <ImageListItemBar  
               sx={{
                background:
                'linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0) 100%)',
              '& .MuiImageListItemBar-title': { color: 'white' },
              '& .MuiImageListItemBar-subtitle': { color: 'white' }
              }}
               actionPosition="right"
              position="top"
               actionIcon={
                <IconButton
                onClick={()=>handleDeleteImage(file)}
                  sx={{ color: '#ADD8E6'  }}
                >
                  <DeleteForeverIcon/>
                </IconButton>
              }/>
            </ImageListItem>
           
       ))
       }
       </ImageList>:(
        <Grid justifyContent="center"  display={"flex"} spacing={1} alignItems={"center"} sx={{ width: isMobile?"80vw":"50vw", height: 450}} container>
           <Grid size={12} display={"flex"} width="100%" flexDirection={"column"}  alignItems={"center"}
           justifyContent={"center"}>
             <Alert sx={{display:"flex"}} severity="info"> <Typography>Please choose 3 images By clicking CHOOSE FILES</Typography>
             <Typography>This helps to your Match to show interest on you</Typography>
             <Typography>Note: This is a manadatory Step.</Typography>
             <Typography>You can access the platform as long as you complete This Step</Typography>
             </Alert>
            </Grid>
        <Grid size={12}>
          <Box  alignItems={"center"} justifyContent={"center"} flexDirection={"column"} display={"flex"} height="100%">
       <PhotoAlbum   sx={{display:"flex",padding:2,height:"50%" ,width:"50%" ,loading:"lazy"}}/>
       </Box>
        </Grid>
        </Grid>
       )}
       <Box display={"flex"} flexDirection={"column"} justifyContent={"center"} alignContent={"center"} gap={2}>
       {isFileArrayLengthThree ?(<Alert  severity="success"> 
          <Typography>You have successfully uploaded 3 images <b>Please Click SUBMIT</b></Typography>
        <Typography>Still you can replace An Image by  Clicking the Cross Button </Typography>
        </Alert> ):(<Alert  severity="error"> 
          <Typography>You cannot proceed if you choose less than 3 images.</Typography>
        <Typography>To replace An Image Click the Cross Button </Typography>
       
        </Alert> )}
        <Button  fullWidth onClick={handleClick}  disabled={isFileArrayLengthThree?true:false} variant="contained">Choose files</Button>
        <form action={additionalDetailsFormAction}>
        <Button  fullWidth  disabled={isFileArrayLengthThree?false:true} variant="contained" type="submit">Submit</Button>
        </form>
        <Typography></Typography>
       </Box>
    </Stack>
    
    
    </>
    
    }
    </CardContent>
    </Card>
    </Box>
    </Box>
    </Container>)}</>)


}

export default AdditionalDetailMatchMaker;