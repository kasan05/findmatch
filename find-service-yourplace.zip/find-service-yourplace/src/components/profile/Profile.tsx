import { Alert, Avatar, Box, Button, Card, CardActionArea, CardContent, CardHeader, Checkbox, Container, createTheme, Dialog, DialogActions, DialogContent, DialogTitle, Grid,  IconButton,  ImageList, ImageListItem, ImageListItemBar, LinearProgress, Paper, Skeleton, Stack, Table, TableBody, TableCell, TableContainer,  TableRow, ThemeProvider, Typography, useMediaQuery } from "@mui/material";
import { red } from "@mui/material/colors";
import Rose from '../../assets/images/rose.png'
import ImageIcon from '@mui/icons-material/Image';
import type { MatchMakerBasicInfoType } from "../Registration/types/MatchMakerBasicInfoType";
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import InfoIcon from '@mui/icons-material/Info';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import React, { Suspense, useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { loadMatchMakerFriendProfile, loadMatchMakerProfile, loadMatchMakerProfileData, loadMatchMakerProfileImages, setProfileImageViewerPromise } from "../../store/matchmakerSlice";
import hindu from "../../assets/images/hindu.png";
import businessman from "../../assets/images/businessman.png";
import country from "../../assets/images/country.png";
import man from "../../assets/images/man.png";
import woman from "../../assets/images/woman.png";
import { useLocation, useNavigate } from "react-router-dom";
import FlagIcon from '@mui/icons-material/Flag';
import BoyIcon from '@mui/icons-material/Boy';
import type { MatchMaker } from "../../types/MatchMaker";
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import CloseIcon from '@mui/icons-material/Close';
import ProfileImageViewer from "./MatchMaker/profileImageViewer";

const theme = createTheme({

  components:{
    MuiAvatar:{
      styleOverrides:{
        root:({theme})=>({
          [theme.breakpoints.down('md')]:{
             width:"20vw",
              height:"20vw"
          },
          [theme.breakpoints.up('md')]:{
              width:"6vw",
              height:"6vw"
          }
        })
      }
    },
    MuiTableContainer:{
      styleOverrides:{
        root:{
          justifyContent:"center",
          alignItems:"left",
          display:"flex",
          flexDirection:"column"
        }
      }
    },
    MuiTypography:{
      styleOverrides:{
        root:{
          fontFamily:"'Montserrat', sans-serif"
        }
      }
    }
}});
interface ProfileProps{
  profileiId?:string
}
const Profile : React.FC<ProfileProps> = ({profileiId})=>{
const imageLoading = useAppSelector(state=>state.matchMaker.imageLoading);
const [dialogOpen,setDialogOpen] = useState(false);
const [isHovered,setIsHovered] = useState(false);
const dispatch = useAppDispatch();
const matchmaker = useAppSelector(state=>state.matchMaker.matchmaker);
const images = useAppSelector(state=>state.matchMaker.images);
const [currIndex,setCurrIndex] = useState<number>(-1);
const loading = useAppSelector(state=>state.matchMaker.loading);
const [imgCurrentIndex,setImgCurrentIndex]=useState<number>(0);
const[isPrevDisabled,setIsPrevDisabled]=useState<boolean>(false);
const[isNexDisabled,setIsNexDisabled]=useState<boolean>(false);
const [profileDialogOpen,setProfileDialogOpen] = useState(false);
const[errorImageSelection,setErrorImageSelection] =useState("");
const[choosenProfilePic,setChoosenProfilePic]=useState<Array<String>>([]);
const dummyArr = ["a","b","c"];
const keyMap = new Map<string, any>();
keyMap.set("profession",businessman);
keyMap.set("religion",hindu);
keyMap.set("gendermale",man);
keyMap.set("genderfemale",woman);

keyMap.set("country",country);

const navigate = useNavigate();
const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const closeDialog = ()=>{
    setDialogOpen(false);
  }
  const onView=(index:number)=>{
    if(index==1){
      setIsPrevDisabled(true);
      setIsNexDisabled(false);
    }
    if(index==(images.length-1)){
      setIsNexDisabled(true);
      setIsPrevDisabled(false);
    }
    setImgCurrentIndex(index)
    setDialogOpen(true);
  }
  const onChangeProfilePicture = (image:String)=>{
    setErrorImageSelection("");
    setChoosenProfilePic((prev)=>
       prev.includes(image)?prev.filter(p=>p!==image):[...prev,image]
    );
  }
  const onMouseEnterImage = (index:number)=>{
    setIsHovered(true)
    setCurrIndex(index);
  }
  const chooseProfilePic = ()=>{
    console.log(choosenProfilePic);
    if(choosenProfilePic && choosenProfilePic.length>1){
      setErrorImageSelection("Select only one Profile Picture")
    }else if(choosenProfilePic && choosenProfilePic.length==0){
      setErrorImageSelection("Select atleast one Profile Picture")
    }else{
      setErrorImageSelection("");
    }
  }
  const onPrev = ()=>{
    console.log(imgCurrentIndex);
    if(imgCurrentIndex==1){
      setIsPrevDisabled(true);
      setIsNexDisabled(false);
    }
    setImgCurrentIndex(prev=>prev-1);
  }
  const onNext = ()=>{
    console.log(imgCurrentIndex);
    if(imgCurrentIndex==(images.length-2)){
      setIsNexDisabled(true);
      setIsPrevDisabled(false);
    }
    setImgCurrentIndex(prev=>prev+1);
  }
  const onprofileUpload=()=>{
    setProfileDialogOpen(true)
  }
  const closeprofileDialog = ()=>{
    setProfileDialogOpen(false);
  }
  const getMap = (matchmaker:MatchMaker):Map<string,any>=> {
    const matchMakerMap = new Map<string, any>();
    switch(matchmaker.country?.toString().toLowerCase()){
      case "singapore":
        matchMakerMap.set("country",{text:"singapore",imgSrc:<FlagIcon/>});
        break;
      default:
        matchMakerMap.set("country",{text:matchmaker.country,imgSrc:<FlagIcon/>});
        break;
    }
    switch(matchmaker.gender?.toString().toLowerCase()){
      case "male":
        matchMakerMap.set("gender",{text:"male",imgSrc:<BoyIcon/>});
        break;
      default:
        matchMakerMap.set("gender",{text:matchmaker.country,imgSrc:<BoyIcon/>});
        break;
    }
    switch(matchmaker.profession?.toString().toLowerCase()){
      case "engineer":
        matchMakerMap.set("profession",{text:matchmaker.profession,imgSrc:<BoyIcon/>});
        break;
      default:
        matchMakerMap.set("profession",{text:matchmaker.profession,imgSrc:<BoyIcon/>});
        break;
    }
    matchMakerMap.set("religion",{text:matchmaker.religion,imgSrc:<BoyIcon/>});
    matchMakerMap.set("caste",{text:matchmaker.caste,imgSrc:<BoyIcon/>});
    matchMakerMap.set("maritalStatus",{text:matchmaker.maritalStatus,imgSrc:<BoyIcon/>});

    return matchMakerMap;
  }
  useEffect(()=>{
    console.log("Loading matchmaker profile stateId:"+profileiId);
    if(profileiId){
      dispatch(loadMatchMakerFriendProfile(profileiId)).unwrap().catch(e=>{navigate("/login")});
      window.history.replaceState({}, document.title);
    }else{
       dispatch(loadMatchMakerProfileImages()).unwrap().catch(e=>{navigate("/login")});
       dispatch(loadMatchMakerProfileData()).unwrap().catch(e=>{navigate("/login")});
    }
  },[dispatch])
    return(<>{loading?( <div style={
      {
        color:"#ADD8E6",
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)', // Offsets the bar's own height/width to be perfectly centered
       zIndex:1
      }
    }>
<Box sx={{ width: 100 ,display:"flex",flexDirection:"column",gap:1,color:"#ADD8E6"}}>
<Typography  sx={{fontSize:{fontWeight:"500"}}}>FindUrMatch</Typography>
  <LinearProgress   />
</Box>

    </div>):(<Container>
       <ThemeProvider theme={theme}>
       {isMobile && <Grid justifyContent={isMobile?"center":"left"} alignItems={isMobile?"center":"left"} mt={3} container direction={"column"} size={{xs:12,md:12}}>
       
          <Stack direction={"row"} justifyContent={"center"} alignItems={"center"} spacing={4}>
          <Avatar sx={{ textAlign:"center",position:"relative","&:hover .MuiSvgIcon-root":{opacity:1}}} aria-label="recipe">
           
              <img src={Rose} width="100%" height="100%" style={{opacity:1}} className="myImage"/>
              <CameraAltIcon onClick={onprofileUpload} sx={{height:"30%" ,width:"30%",display:"flex",opacity:0,
                justifyContent:"center",alignItems:"center",top:"35%",left:"35%",position:"absolute"}}/>
           
            </Avatar>
            <Stack direction={"column"} alignContent={"center"} justifyContent={"center"} alignItems={"left"} gap={0}>
            <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1rem'}}}>{matchmaker?.name?.charAt(0).toUpperCase()+matchmaker?.name?.slice(1).toLowerCase()}</Typography>
            <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1rem'}}}>{matchmaker?.country?.charAt(0).toUpperCase()+matchmaker?.country?.slice(1).toLowerCase()}</Typography>
            {/* <Button startIcon={<TextsmsIcon/>}>Message</Button> */}
            </Stack>
          </Stack>

        </Grid>}
        <Grid container justifyContent={"center"} justifyItems={"center"} mt={5} mb={5} spacing={5}>
         
            <Grid size={{xs:12,md:4}} >
              <Card sx={{ width: "100%",height:"100%",  borderRadius: 3 }}>
                <CardHeader
              sx={{background:"#ADD8E6"}}
                title={
                  <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1.1rem'}}}>
                <Stack direction="row" alignItems="center" gap={1}>
                            <InfoIcon sx={{color:"black"}} />
                            <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1.0rem'}}}>
                            ABOUT ME
                            </Typography>
                          </Stack>
              
                </Typography>
                }/>
                <CardContent sx={{padding:5}}>
               {isMobile?(
                <Box display={"flex"}flexDirection={"column"} justifyContent={"center"} alignItems={"center"}>
                 <TableContainer component={Paper} elevation={0} >
                 <Table sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                 <TableBody>
                   {matchmaker && Array.from(getMap(matchmaker)).map(([key,value])=>(
                    <TableRow>
                <TableCell>
                <Typography variant="body2">
                 {key?.toString().charAt(0).toUpperCase()+key?.toString().slice(1).toLocaleLowerCase()}
                   </Typography>
                </TableCell>
                <TableCell>
                <Typography sx={{fontWeight:530}}>
                {value?.text?.toString().charAt(0).toUpperCase()+value?.text?.toString().slice(1).toLocaleLowerCase()}
                </Typography>
                </TableCell>
                 </TableRow>
                 
                   ))}</TableBody>
                   </Table>
                   </TableContainer></Box>
               ):(
                <TableContainer component={Paper} elevation={0}>
                <Table sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                <TableBody>
                  {matchmaker && Array.from(getMap(matchmaker)).map(([key,value])=>(
                   <TableRow>
               <TableCell>
                <Stack  flexDirection={"column"} display={"flex"} justifyContent={"center"} alignItems={"center"}>
               <Typography variant="caption">
                {key?.toString().charAt(0).toUpperCase()+key?.toString().slice(1).toLocaleLowerCase()}
                  </Typography>
                  <Typography sx={{fontWeight:500}}>
               {value?.text?.toString().charAt(0).toUpperCase()+value?.text?.toString().slice(1).toLocaleLowerCase()} 
               </Typography>
                  </Stack>
               </TableCell>
              
                </TableRow>
                
                  ))}</TableBody>
                  </Table>
                  </TableContainer>

               )}
                  </CardContent>
                  </Card>
             
            </Grid>
            <Grid size={{xs:12,md:8}} justifyContent={"left"} pt={isMobile?2:0} justifyItems={"left"} container direction={"column"}>
              {isMobile ? 
                  (<Card>
                    {imageLoading?(
                   <Skeleton animation="wave" variant="rectangular" width={"100%"} height={50}/>
                    ):(<CardHeader 
                      sx={{background:"#ADD8E6"}}
                    title={
                      <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1.1rem'}}}>
                 <Stack direction="row" alignItems="center" gap={1}>
                              <ImageIcon sx={{color:"black"}} />
                              <Typography variant="h5" sx={{fontSize:{xs:'1.1rem',md:'1.1rem'}}}>
                              PROFILE PICTURES
                              </Typography>
                            </Stack>
                
                  </Typography>
                    }/>)}
                    <CardContent >
                    <ImageList sx={{width:{sx:"50vw",md:"50vw"}, height: "65vh",placeItems:"center"}}>
                    {false && <Typography sx={{textAlign:"center",placeItems:"center"}}>No image was uploaded lateley</Typography>}
                    {imageLoading?(
                      dummyArr.map((image:string,index:number)=>(
                        <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
                    
                        <Skeleton animation="wave" width={"40vw"} height={"30vh"}/>
                                                  </ImageListItem>
                      ))
                    ):
                    images && images.map((image,index:number)=>(
                      <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
                  
                      <img src={`data:image/jpeg;base64,${image}`}  style={{width:"100%",height:"100%"}} loading="lazy"/>
                      
                      { isHovered && index==currIndex  && <ImageListItemBar title={<Button id={image.toString()} onClick={()=>onView(index)} startIcon={<ZoomInIcon/>}>VIEW</Button>}/> }
                        </ImageListItem>
                    ))}
                    
                    </ImageList>
                </CardContent></Card> ):(
                  <Stack direction={"column"} gap={5}>
                           <Grid justifyContent={"left"} sx={{padding:5,background:"#ADD8E6",borderRadius:3}} alignItems={"left"} container direction={"column"}>
       
                                <Stack direction={"row"} justifyContent={"center"} alignContent={"center"} spacing={4}>
                                <Avatar sx={{ bgcolor: red[500],textAlign:"center",position:"relative","&:hover .MuiSvgIcon-root":{opacity:1}}} aria-label="recipe">
                                    <img src={Rose} width="100%" height="100%"/>
                                    <CameraAltIcon  sx={{height:"30%" ,width:"30%",display:"flex",opacity:0,
                justifyContent:"center",alignItems:"center",top:"35%",left:"35%",position:"absolute"}} onClick={onprofileUpload}/>
                                  </Avatar>
                                  <Stack direction={"column"} alignContent={"center"} justifyContent={"center"}>
                                  <Typography variant="h5" sx={{fontSize:{xs:'1rem',md:'1rem'}}}>{matchmaker?.name?.charAt(0).toUpperCase()+matchmaker?.name?.slice(1).toLowerCase()}</Typography>
                                  <Typography variant="h5" sx={{fontSize:{xs:'1rem',md:'1rem'}}}>{matchmaker?.country?.charAt(0).toUpperCase()+matchmaker?.country?.slice(1).toLowerCase()}</Typography>
                                  {/* <Button startIcon={<ChatIcon/>}>Message</Button> */}
                                  </Stack>
                                </Stack>

                            </Grid>
                            <Card>
                              <CardHeader 
                               />
                              <CardContent >
                              <ImageList sx={{width:{sx:"50vw",md:"50vw"}, height: "65vh",placeItems:"center"}}>
                              {false && <Typography sx={{textAlign:"center",placeItems:"center"}}>No image was uploaded lateley</Typography>}

                              {images && images.map((image,index:number)=>(
                                <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
                            
                                <img src={`data:image/jpeg;base64,${image}`}  style={{width:"100%",height:"100%"}} loading="lazy"/>
                                
                                { isHovered && index==currIndex  && <ImageListItemBar title={<Button id={image.toString()} onClick={()=>onView(index)} startIcon={<ZoomInIcon/>}>VIEW</Button>}/> }
                                  </ImageListItem>
                              ))}
                              
                              </ImageList>
                        
                          </CardContent>
                          </Card>

                  </Stack>


                )}
          </Grid>
        </Grid>
       </ThemeProvider>
       <Dialog onClose={closeDialog} open={dialogOpen}>
        <DialogContent>
           <Card elevation={0} sx={{display:"flex",justifyContent:"center",alignItems:"center",flexDirection:"column",gap:2}}>
            <img src={`data:image/jpeg;base64,${images[imgCurrentIndex]}`} 
            width={"100%"} height={"100%"} />  
            </Card> 
            </DialogContent>
       <DialogActions sx={{display:"flex",justifyContent:"center",alignItems:"center",flexDirection:"column"}}>
       <Stack spacing={2} flexDirection={"row"} display="flex" justifyContent={"center"} alignItems={"center"}>
             <Button variant="text" startIcon={<ArrowBackIcon/>} onClick={onPrev} disabled={isPrevDisabled}>PREV</Button>
             <Button  variant="text" startIcon={<ArrowForwardIcon/>} onClick={onNext} disabled={isNexDisabled}>NEXT</Button>
             </Stack>
        </DialogActions>   
        </Dialog>  
        <Dialog onClose={closeprofileDialog} open={profileDialogOpen}>
          <DialogTitle  sx={{background:"#ADD8E6"}} display={"flex"} flexDirection={"row"} justifyContent={"center"} alignItems={"center"}>
          <Typography sx={{fontWeight:500}} variant="body1">PROFILE PICTURE</Typography>
          <IconButton sx={{marginLeft:"auto"}} onClick={closeprofileDialog} ><CloseIcon/></IconButton>
          </DialogTitle>
        <DialogContent>
        <Card elevation={0}>
                              <CardHeader 
                               />
                              <CardContent >
                              <ImageList sx={{width:{sx:"50vw",md:"50vw"}, height: "65vh",placeItems:"center"}}>
                              {false && <Typography sx={{textAlign:"center",placeItems:"center"}}>No image was uploaded lateley</Typography>}

                              {images && images.map((image,index:number)=>(
                                <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
                            
                                <img src={`data:image/jpeg;base64,${image}`}  style={{width:"100%",height:"100%"}} loading="lazy"/>
                                
                                <ImageListItemBar title={
                                  <Button startIcon={<Checkbox onChange={()=>onChangeProfilePicture(image)} sx={{color:"white"}} size="small"/>}><Typography>SELECT</Typography></Button>
                                  }/> 
                                  </ImageListItem>
                              ))}
                              
                              </ImageList>
                        
                          </CardContent>
                          </Card>
        </DialogContent>
<DialogActions sx={{justifyContent:"center",flexDirection:"column",alignItems:"center",display:"flex"}}>
{errorImageSelection!=="" && (<Alert severity="error">{errorImageSelection}</Alert>)}
             <Button onClick={chooseProfilePic}>CHOOSE</Button>
     
</DialogActions>
        </Dialog>
    </Container>)}</>)
}
export default Profile;