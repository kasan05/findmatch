import Profile from "../Profile";

const MatchMakerProfile = ()=>{
    return (<Profile/>)
}
export default MatchMakerProfile;