import { Button, ImageListItem, ImageListItemBar, Skeleton } from "@mui/material";
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { use, useEffect } from "react";
import { loadMatchMakerProfileImages, setProfileImageViewerPromise } from "../../../store/matchmakerSlice";

interface ProfileImageViewerProps{
    onMouseEnterImage:(index:number)=>void,
    setIsHovered:(state:boolean)=>void,
    isHovered:boolean,
    currIndex:number,
    onView:(index:number)=>void,
    ProfileImageViewerPromise:any

}
const ProfileImageViewer:React.FC<ProfileImageViewerProps> = ({onMouseEnterImage,setIsHovered,isHovered,
    currIndex,onView,ProfileImageViewerPromise
})=>{
   
    const data:[] = [];
    console.log(data)
    const dummyArray =["a","b","c"]
    return(
        <>
        {data ? data.map((image:string,index:number)=>(
          <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
      
          <img src={`data:image/jpeg;base64,${image}`}  style={{width:"100%",height:"100%"}} loading="lazy"/>
          
          { isHovered && index==currIndex  && <ImageListItemBar title={<Button id={image.toString()} onClick={()=>onView(index)} startIcon={<ZoomInIcon/>}>VIEW</Button>}/> }
            </ImageListItem>
        )):dummyArray.map((image:string,index:number)=>(
            <ImageListItem  key={image.toString()} onMouseEnter={(e) => onMouseEnterImage(index)}  onMouseLeave={() => setIsHovered(false)}> 
        
            <Skeleton variant="rectangular"style={{width:"100%",height:"100%"}} />

            { isHovered && index==currIndex  && <ImageListItemBar title={<Button id={image.toString()} onClick={()=>onView(index)} startIcon={<ZoomInIcon/>}>VIEW</Button>}/> }
              </ImageListItem>
          ))}
        </>
        )
}
export default ProfileImageViewer;