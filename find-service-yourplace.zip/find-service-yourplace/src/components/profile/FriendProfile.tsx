import { useLocation, useNavigate } from "react-router-dom";
import Profile from "./Profile"
import { useEffect } from "react";

const FriendProfile = ()=>{

    const location = useLocation();
    const stateId = location.state?.id;
    const navigate = useNavigate();

    useEffect(()=>{

        if(!stateId){
            navigate("/match-maker/profile");
            return;
        }
    },[stateId])

    return <Profile profileiId={stateId}/>
}

export default FriendProfile;
