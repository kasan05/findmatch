import { AppBar, Toolbar, Typography, Container, Button, 
  useTheme, useMediaQuery, List, ListItem, ListItemButton, ListItemText, 
  IconButton, Avatar, Menu, MenuItem, Divider, ListItemIcon, createTheme, 
  ThemeProvider, Stack, SwipeableDrawer, Grid, Tooltip, keyframes, ClickAwayListener } from "@mui/material";
import SearchIcon from '@mui/icons-material/Search';
import MenuIcon from '@mui/icons-material/Menu';
import { useCallback, useState, type ReactElement } from "react";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useAuth } from "../../context/AppAuthContext";
import HomeIcon from '@mui/icons-material/Home';
import CloseIcon from '@mui/icons-material/Close';
import { logoutUser } from "../../store/brokerSlice";
import EmailIcon from '@mui/icons-material/Email';
import HouseIcon from '@mui/icons-material/House';
import KeyOffIcon from '@mui/icons-material/KeyOff';
import KeyIcon from '@mui/icons-material/Key';
import NoAccountsIcon from '@mui/icons-material/NoAccounts';
import MailLockIcon from '@mui/icons-material/MailLock';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import LockIcon from '@mui/icons-material/Lock';
import DraftsIcon from '@mui/icons-material/Drafts';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import PeopleIcon from '@mui/icons-material/People';

type LinkItem ={
    text:string
    icon:ReactElement
}
const colorChange = keyframes`
  0% {
    color: red; 
  }
  50% {
    color: green;
  }
  100% {
    color: blue;
  }
`;
const themeA = createTheme({
  components: {
    MuiDrawer: {
      styleOverrides: {
        paper: {
        //  background:"#ADD8E6"
        },
      },
    },
    MuiListItemButton:{
      styleOverrides:{
        root:{
          position:"relative"
        }
      }
    },
    MuiListItemIcon:{
      styleOverrides:{
        root:{
         
        }
      
      }
    },
    MuiListItem:{
      styleOverrides:{
        root:{
          "&:hover":{color:"#000080",paddingLeft:0,paddingRight:"30px"}
        }
      }
    },
    MuiButton:{
      styleOverrides:{
        root:{
           fontFamily:"'Montserrat', sans-serif"
        }
      }
    },
    MuiAppBar:{
      styleOverrides:{
        root:{
           background:"#ADD8E6",
           color:"black"
        }
      }
    },
    MuiTypography:{
      styleOverrides:{
        root:{
          fontFamily:"'Montserrat', sans-serif"
        }
      }
    }
  },

});
const Navbar =()=>{
    const  user = useAppSelector(state=>state.broker.user)
    const [drawerOpen,setDrawerOpen]= useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const[mouseEnter,setMouseEnter]=useState<string>("");
    const[menuMouseEnter,setMenuMouseEnter]=useState<string>("");
    const navbarTitle ="FindUrMatch";
    const menuOpen = Boolean(anchorEl);
    const theme = useTheme()
    const navigate = useNavigate();
    const dispatch = useAppDispatch();
    const onSearchIcon = ()=>{
      console.log("/sercahhsh ")
      navigate("/search");
      return;
    }
    const onHome =()=>{
      if(user){
         if(user?.userStatus==="APPROVED"){
          navigate("/match-maker/profile",{state:{id:2}});
          return;
         }else if(user?.userStatus==="INCOMPLETE_DATA"){
          navigate("/match-maker/additional-details");
          return;
         }
      }
        navigate("/");
    }
    const onLogin = ()=>{
      navigate("/login");
    }
    const onClickDrawerButton = (text:string)=>{
      setDrawerOpen(false);
      switch(text){
        case "Home":{
          if(user){
            if(user?.userStatus==="APPROVED"){
               window.location.href="/match-maker/profile"
              return;
             }else if(user?.userStatus==="INCOMPLETE_DATA"){
              navigate("/match-maker/additional-details");
              return;
             }
            // navigate("/match-maker/profile");
          }else{
            navigate("/");
          }
          break;
        }
        case "Profile":{
          navigate("/match-maker/profile");
          break;
        }
        case "Search":{
          navigate("/search");
          break;
        }
        case "Login":{
          navigate("/login");
          break;
        }
        case "Logout":{
          logout();
          break;
        }
        case "Inbox":{
          navigate("/inbox");
          break;
        }
        default:{
          if(user){
            navigate("/match-maker/profile");
            return;
          }else{
            navigate("/");
            return;
          }
          break;
        }
          
      }
    }
    const onMessageIcon =()=>{
      navigate("/inbox");
    }
    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
      };
    const handleClose = () => {
        setAnchorEl(null);
      };
    const isMobile = useMediaQuery(theme.breakpoints.down("md"));

    const toggleDrawer = (open:boolean)=>()=>{
        setDrawerOpen(open);
    }
    const logout=useCallback(()=>{
      console.log("calling...")
       dispatch(logoutUser()).unwrap().then(res=>{
        navigate("/login");
       })
    },[navigate,dispatch])
    const drawerLinks : Array<LinkItem> = [{
        text:"Home",
        icon:mouseEnter==="Home"?<HouseIcon/>:<HomeIcon/> 
    },{
        text:"Profile",
        icon:mouseEnter==="Profile"?<PeopleIcon/>:<NoAccountsIcon/>
    },{
      text:"Search",
      icon:mouseEnter==="Search"?<PersonSearchIcon/>:<SearchIcon/>
  },{
    text:"Inbox",
    icon:mouseEnter==="Inbox"?<DraftsIcon/>:<MailLockIcon/>
},
  {
    text:"Logout",
    icon:mouseEnter==="Logout"?<LockIcon/>:<LockOpenIcon/>
},{
  text:"Login",
  icon:mouseEnter==="Login"?<KeyIcon/>:<KeyOffIcon/>
}
]
const onFriendReq = ()=>{
  navigate("/friends/request")
}
const onMouseEnterFunc=(item:LinkItem)=>{
    setMouseEnter(item.text);
}
const onMouseLeaveFunc =(item:LinkItem)=>{
  setMouseEnter("");
}
const onMouseEnterMenuFunc = (val:string)=>{
  setMenuMouseEnter(val)
}
const onMouseLeaveMenuFunc = (val:string)=>{
  setMenuMouseEnter("")
}
const onLogoutMenuMouseEnter=(val:string)=>{
  setMenuMouseEnter(val)
}
const onLogoutMenuMouseLeave=(val:string)=>{
  setMenuMouseEnter("")
}
    return(
       <>
       <ThemeProvider theme={themeA}>
       <AppBar position="sticky" color="primary" >
         <Container>
         <Toolbar>
            <SearchIcon sx={{cursor: 'pointer'}} onClick={onHome}/>
           <Typography onClick={onHome} sx={{flexGrow:1,cursor: 'pointer'}} variant="h5">
             {navbarTitle}
           </Typography>
           {
            isMobile && (
                <IconButton color="inherit" onClick={toggleDrawer(true)}>
                    <MenuIcon/>
                </IconButton>
            )
           }
           {
            !isMobile && (
                <>
               <Stack direction={"row"} spacing={2} justifyContent={"center"} alignContent={"center"} sx={{mr:2}}>
               <Typography sx={{cursor: 'pointer','&:hover': { color: '#000080',transform:"scale(1.1)" }}} color="inherit" 
                onTouchStart={()=>onMouseEnterMenuFunc("Home")}
                onTouchEnd={()=>onMouseLeaveMenuFunc("Home")}
               onMouseEnter={()=>onMouseEnterMenuFunc("Home")}
               onMouseLeave={()=>onMouseLeaveMenuFunc("Home")}
               onClick={onHome}>{menuMouseEnter==="Home"?<HouseIcon/>:<HomeIcon/>}</Typography>
               <Typography sx={{display:user?"none":"",cursor: 'pointer','&:hover': { color: '#000080',transform:"scale(1.1)" }}} color="inherit" 
                onTouchStart={()=>onMouseEnterMenuFunc("Login")}
                onTouchEnd={()=>onMouseLeaveMenuFunc("Login")}
                onMouseEnter={()=>onMouseEnterMenuFunc("Login")}
                onMouseLeave={()=>onMouseLeaveMenuFunc("Login")}
               onClick={onLogin}>
                <Tooltip title="Login">{menuMouseEnter?<KeyIcon/>:<KeyOffIcon/>}</Tooltip></Typography>
                <Typography   sx={{display:user && user?.userStatus==="APPROVED"?"":"none", cursor: 'pointer','&:hover': { color: '#000080',transform:"scale(1.1)" }}}
                onTouchStart={()=>onMouseEnterMenuFunc("Search")}
                onTouchEnd={()=>onMouseLeaveMenuFunc("Search")}
                onMouseEnter={()=>onMouseEnterMenuFunc("Search")}
                onMouseLeave={()=>onMouseLeaveMenuFunc("Search")}
                 onClick={onSearchIcon}  color="inherit">
                  {menuMouseEnter==="Search"?<PersonSearchIcon/>:<SearchIcon/>}
                  </Typography>
                    <Typography  sx={{display:user && user?.userStatus==="APPROVED"?"":"none", cursor: 'pointer','&:hover': { color: '#000080',transform:"scale(1.1)" }}}
                     onClick={onFriendReq}
                     onTouchStart={()=>onMouseEnterMenuFunc("Profile")}
                      onTouchEnd={()=>onMouseLeaveMenuFunc("Profile")}
                     onMouseEnter={()=>onMouseEnterMenuFunc("Profile")}
                    onMouseLeave={()=>onMouseLeaveMenuFunc("Profile")}
                      color="inherit" >
                      {menuMouseEnter==="Profile"?<PeopleIcon/>:<NoAccountsIcon/>}</Typography>
                    <Typography sx={{display:user && user?.userStatus==="APPROVED"?"":"none", cursor: 'pointer','&:hover': { color: '#000080',transform:"scale(1.1)" }}}
                     onClick={onMessageIcon}
                     onTouchStart={()=>onMouseEnterMenuFunc("Inbox")}
                      onTouchEnd={()=>onMouseLeaveMenuFunc("Inbox")}
                     onMouseEnter={()=>onMouseEnterMenuFunc("Inbox")}
                    onMouseLeave={()=>onMouseLeaveMenuFunc("Inbox")}
                      color="inherit">{menuMouseEnter==="Inbox"?<DraftsIcon/>:<EmailIcon/>}</Typography>
                    </Stack>
                    <Button  sx={{display:user?"":"none"}} color="inherit" href="#href" onClick={handleClick}>
                      <Avatar>{user?.name?.charAt(0).toLowerCase()}</Avatar></Button>
                    <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={menuOpen}
        onClose={handleClose}
        onClick={handleClose}
        slotProps={{
          paper: {
            elevation: 0,
            sx: {
              overflow: 'visible',
              filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
              mt: 1.5,
              '& .MuiAvatar-root': {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
                background:"#ADD8E6"
              },
              '&::before': {
                content: '""',
                display: 'block',
                position: 'absolute',
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: 'background.paper',
                transform: 'translateY(-50%) rotate(45deg)',
                zIndex: 0,
                background:"#ADD8E6"
              },
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
         <MenuItem onClick={handleClose}>
          <Avatar /> <Typography variant="body1">{"Hi "+user?.name?.charAt(0).toUpperCase()+user?.name?.slice(1).toLowerCase()}</Typography>
        </MenuItem>
        <Divider />
        <MenuItem onClick={handleClose} 
        onTouchStart={()=>onLogoutMenuMouseEnter("activate")}
        onTouchEnd={()=>onLogoutMenuMouseLeave("activate")}
        onMouseEnter={()=>onLogoutMenuMouseEnter("activate")}
        onMouseLeave={()=>onLogoutMenuMouseLeave("activate")}
        sx={{
          alignItems:"center",
          justifyContent:"center",
          display:"flex",
           '&:hover .MuiListItemIcon-root': {
            '@keyframes a':{
              '80%':{
                 transform:"rotate(1deg)"
              },
              '100%':{
               
                transform:"rotate(5deg)"
              }
            },
            animation:"a 2s infinite ease-in-out",
            color:"#ADD8E6", //#ADD8E6
            transform:"scale(1.1)",
            left: 'calc(100% - 2rem - 2px)',
      },
      '&:hover .MuiTypography-root': {
        color:"#ADD8E6",
        fontWeight:"400"
      }
        }}>
          <ListItemIcon sx={{
             position: 'absolute',
             left: '10px',
             transition: 'left 0.6s ease-in-out',
          }}>
            {menuMouseEnter=="activate"?<LockIcon fontSize="small" />:<LockOpenIcon fontSize="small"/>}
          </ListItemIcon>
          <Typography variant="body1" onClick={logout}>Logout</Typography>
        </MenuItem>
      </Menu>
                </>
            )
           }
         </Toolbar>
         </Container>
       
       </AppBar>
       <SwipeableDrawer  
        slotProps={{
          paper: {
            sx: { width: 390 }, // Sets width to 300px
          },
        }}
       keepMounted
       transitionDuration={150}
       disableSwipeToOpen={false}
       onOpen={toggleDrawer(true)}
       anchor="right" open={drawerOpen} onClose={toggleDrawer(false)}>
        <Stack  alignItems="center" direction={"row"} justifyContent={"center"} sx={{padding:2,height:"26px",background:"#ADD8E6"}}>
          
            <Stack direction={"row"} justifyContent={"center"} alignItems={"center"}>
            <SearchIcon/>
            <Typography  variant="body1"> FindUrMatch </Typography>
            </Stack>
            
           
              <Button  sx={{marginLeft:"auto"}} >
                  <CloseIcon  onClick={toggleDrawer(false)}/></Button>
         </Stack>
        <Grid container
         justifyContent={"left"} 
         alignItems={"left"}
         size={12}
         pt={2}
         width={"auto"}
         direction={"column"}
         >
            <List sx={{padding:5,}}>
                {drawerLinks.map((item:LinkItem,index)=>(
                  <>
                   <ClickAwayListener onClickAway={()=>onMouseEnterFunc(item)}>
                    <ListItem 
                    key={index} disablePadding 
                    onTouchStart={()=>onMouseEnterFunc(item)}
                    onTouchEnd={()=>onMouseLeaveFunc(item)}
                    onMouseEnter={()=>onMouseEnterFunc(item)}
                    onMouseLeave={()=>onMouseLeaveFunc(item)}
                  
                    sx={{pb:1,position: 'relative', alignItems: 'center',
                      padding:2,
                      display:user && (item.text==="Home"|| user?.userStatus==="APPROVED" && item.text==="Profile" || user?.userStatus==="APPROVED" && item.text==="Inbox" || user?.userStatus==="APPROVED" && item.text==="Search" || item.text==="Logout")?
                      "flex":
                      !user && (item.text==="Home" ||item.text==="Login") ?"flex":
                      "none",
                      '&:hover .MuiListItemIcon-root': {
                        '@keyframes a':{
                          '80%':{
                             transform:"rotate(1deg)"
                          },
                          '100%':{
                           
                            transform:"rotate(5deg)"
                          }
                        },
                        animation:"a 2s infinite ease-in-out",
                        color:"#ADD8E6", //#ADD8E6
                        transform:"scale(1.1)",
                        left: 'calc(100% - 3rem - 5px)',
                  },
                  '&:hover .MuiListItemText-root': {
                    fontWeight:"900"
                  }
                    }}>
                       
                        <ListItemButton  onClick={()=>onClickDrawerButton(item.text)} component="a" aria-label={`Navigate to ${item.text}`}>
                        <ListItemIcon 
                        sx={{
                          position: 'absolute',
                          left: '16px',
                          transition: 'left 0.6s ease-in-out',
                        }}
                        >{item.icon}</ListItemIcon>
                        <ListItemText sx={{pl: 4 ,color:mouseEnter===item.text?"#ADD8E6":"",
                          fontWeight:mouseEnter===item.text?"900":"normal"
                        }}>
                         
                          <Typography  variant="body2">{item.text}</Typography>
                        
                         
                          </ListItemText>
                          </ListItemButton>
                    </ListItem>
                    </ClickAwayListener>
                    <Divider sx={{display:user && (item.text==="Home"|| user?.userStatus==="APPROVED" && item.text==="Profile" || user?.userStatus==="APPROVED"  && item.text==="Inbox" || user?.userStatus==="APPROVED"  &&  item.text==="Search" || item.text==="Logout")?"":!user&&(item.text==="Home" ||item.text==="Login") ?"":"none",
                     
                    }}/></>
                ))}
                </List>
            </Grid>
       </SwipeableDrawer></ThemeProvider>
       </>
    )
}

export default Navbar;