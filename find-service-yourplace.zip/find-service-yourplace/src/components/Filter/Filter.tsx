import { createTheme,useMediaQuery } from "@mui/material"
import { useState } from "react";
import SideMenuBar from "./SideMenuBar";
import type { FilterInput } from "../../types/FilterInput";

const theme = createTheme({

    components:{
        MuiListItemIcon:{
            styleOverrides:{
                root:({theme})=>({
                    [theme.breakpoints.down('md')]:{
                        paddingLeft:"3rem",
                    },
                    [theme.breakpoints.up('md')]:{
                            fontSize:"2rem"
                    }
                })
            }
        },
        MuiButton:{
            styleOverrides:{
                root:({theme})=>({
                    [theme.breakpoints.down('md')]:{
                       fontSize:"0.6rem",
                       width:"6rem",
                       marginLeft:"5rem !important"
                    },
                    [theme.breakpoints.up('md')]:{
                            fontSize:"1rem"
                    }
                })
            }
        }
    }
})
interface FilterProps{
    castes:Array<String>,
    countries:Array<String>,
    maritalStatuses:Array<String>,
    genders:Array<String>,
    professions:Array<String>,
    religions:Array<String>,
    rowPerpage:number,
    page:number,
    closeSideBar:(open:boolean)=>void,
    passFilterData:(filterData:FilterInput)=>void
}
const Filter:React.FC<FilterProps> = ({castes,countries,maritalStatuses,genders,professions,religions,rowPerpage,page,closeSideBar,passFilterData})=>{
    const [activeList,setActiveList] = useState<number[]>([]);
    const [cindex,setCIndex] = useState(0);
    const [open,setOpen] = useState(false);
    const mapSubCategory = new Map<number,string[]>();
    mapSubCategory.set(0,[
        "SriLanka",
        "Australia",
        "UK"
    ]);
    mapSubCategory.set(1,["North","South","West","East"]);     
    mapSubCategory.set(2,["Hindu","Christianity","Muslim","Buddhist"]);     
    mapSubCategory.set(3,["Engineer","Doctor","Teacher","Accountant"]);

    const handleClick = (index:number)=>{
        console.log(activeList);
        setCIndex(index);
        setOpen(!open);
        const i = activeList.indexOf(index);
       if(i==-1){
        activeList.push(index);
       }else{
        activeList.splice(i,1);
       }
        setActiveList([...activeList]);
    }
    const handleFilterInput = (filterInput:FilterInput)=>{
        handleFilterInput(filterInput);
    }
    return(
    <><SideMenuBar countries={countries} castes={castes} religions={religions} maritalStatuses={maritalStatuses}
    genders={genders} professions={professions} rowPerpage={rowPerpage} page={page} closeSideBar={closeSideBar}
    passFilterData={passFilterData}/>
    </>
        )
}
export default Filter;