import {AccordionDetails,  Button, Checkbox,Grid,Slider,Typography } from "@mui/material";
import { startTransition, useCallback, useEffect, useRef, useState, useTransition } from "react";
import MuiAccordion from '@mui/material/Accordion';
import type  { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, {
    accordionSummaryClasses,
  } from '@mui/material/AccordionSummary';
import FormControlLabel from '@mui/material/FormControlLabel';
import type { AccordionSummaryProps} from '@mui/material/AccordionSummary';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import { styled } from '@mui/material/styles';
import FilterListIcon from '@mui/icons-material/FilterList';
import countriesFromFile from "./countries";
import { useAppDispatch } from "../../store/hooks";
import { loadCountries } from "../../store/countrySlice";
import type { FilterInput } from "../../types/FilterInput";
import type { Page } from "../../types/Page";
import { loadMatchMakerDataForSearchPage } from "../../store/matchmakerSlice";


const Accordion = styled((props: AccordionProps) => (
    <MuiAccordion disableGutters elevation={0} square {...props} />
  ))(({ theme }) => ({
    border: `1px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
      borderBottom: 0,
    },
    '&::before': {
      display: 'none',
    },
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
    <MuiAccordionSummary
      expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
      {...props}
    />
  ))(({ theme }) => ({
    backgroundColor: 'rgba(0, 0, 0, .03)',
    flexDirection: 'row-reverse',
    [`& .${accordionSummaryClasses.expandIconWrapper}.${accordionSummaryClasses.expanded}`]:
      {
        transform: 'rotate(90deg)',
      },
    [`& .${accordionSummaryClasses.content}`]: {
      marginLeft: theme.spacing(1),
    },
    ...theme.applyStyles('dark', {
      backgroundColor: 'rgba(255, 255, 255, .05)',
    }),
  }));

interface SideMenuBarProps{
  castes:Array<String>,
  countries:Array<String>,
  maritalStatuses:Array<String>,
  genders:Array<String>,
  professions:Array<String>,
  religions:Array<String>,
  rowPerpage:number,
  page:number,
  closeSideBar:(open:boolean)=>void
  passFilterData:(filterData:FilterInput)=>void
}
  
const SideMenuBar:React.FC<SideMenuBarProps> =({castes,countries,maritalStatuses,genders,professions,religions,
  rowPerpage,page,closeSideBar,passFilterData
})=>{
    const [expanded, setExpanded] = useState<string | false>('');
    const[selectedCountriesTemp,setSelectedCountriesTemp] = useState<Array<string>>([]);
    const[selectedCastesTemp,setSelectedCastesTemp] = useState<Array<string>>([]);
    const[selectedProfessionsTemp,setSelectedProfessionsTemp] = useState<Array<string>>([]);
    const[selectedReligionsTemp,setSelectedReligionsTemp] = useState<Array<string>>([]);
    const [ageArr,setAgeArr]= useState<Array<number>>([]); 
     const marks = [
      {
        value: 20,
        label: '20',
      },
      {
        value: 50,
        label: '50',
      }
    ];
    function valuetext(value: number) {
      return `${value}`;
    }
    const dispatch  = useAppDispatch();

    const onClickFilterResult = useCallback(()=>{
        const fInput:FilterInput = {
          selectedCountriesTemp:selectedCountriesTemp,
          selectedCastesTemp: selectedCastesTemp,
          selectedProfessionsTemp: selectedProfessionsTemp,
          selectedReligionsTemp: selectedReligionsTemp,
          ageArr: ageArr
        }
       
        //call function
        console.log(rowPerpage);
        console.log(page);
          const pageObj:Page = {
              limit:rowPerpage,
              offset:page*rowPerpage,
              filterInput:fInput
          }
         
        dispatch(loadMatchMakerDataForSearchPage(pageObj)).unwrap().then(res=>{
          closeSideBar(true);
          passFilterData(fInput);
        }).catch(e=>{
          closeSideBar(true);
        });
       
    },[dispatch,selectedCountriesTemp,selectedCastesTemp,selectedProfessionsTemp,selectedReligionsTemp,ageArr,closeSideBar,passFilterData])

    const handleChange =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
      setExpanded(newExpanded ? panel : false);
    };

    useEffect(()=>{
      dispatch(loadCountries(countriesFromFile));
    })
    const [isPending, startTransition] = useTransition();
    const abortControllerRef = useRef<AbortController|null>(null);
  const  handleCountryChangeCheckBox =(country:string)=>{
    let cArr:string[]=[];
      setSelectedCountriesTemp((prev)=>{
        if(prev.includes(country)){
          cArr = prev.filter(i=>i!==country)
          return cArr;
        }
        cArr = [...prev,country]
        return cArr;
      })  

      console.log(cArr);
      if(abortControllerRef.current){
        abortControllerRef.current.abort();
      }
      const controller = new AbortController();
      abortControllerRef.current = controller;
      const fInput:FilterInput = {
        selectedCountriesTemp:cArr,
        selectedCastesTemp: selectedCastesTemp,
        selectedProfessionsTemp: selectedProfessionsTemp,
        selectedReligionsTemp: selectedReligionsTemp,
        ageArr: ageArr
      }
     
      //call function
      console.log(rowPerpage);
      console.log(page);
        const pageObj:Page = {
            limit:rowPerpage,
            offset:page*rowPerpage,
            filterInput:fInput,
            signal:controller.signal
        }
      
      startTransition(async()=>{
         dispatch(loadMatchMakerDataForSearchPage(pageObj));
      })
     
    }
   const handleProfessionChangeCheckBox = (profession:string)=>{
      setSelectedProfessionsTemp((prev)=>{
        if(prev.includes(profession)){
          return prev.filter(i=>i!==profession);
        }
        return [...prev,profession];
      })   
      console.log(profession);
   }
   const handleReligionChangeCheckBox =(religion:string)=>{
      setSelectedReligionsTemp((prev)=>{
        if(prev.includes(religion)){
          return prev.filter(i=>i!==religion);
        }
        return [...prev,religion];
      })   
      console.log(religion);
   }
   const handleCasteChangeCheckBox = (caste:string)=>{
      setSelectedCastesTemp((prev)=>{
        if(prev.includes(caste)){
          return prev.filter(i=>i!==caste);
        }
        return [...prev,caste];
      })   
      console.log(caste);
   }
   const onChangeAge = (event: Event, newValue: number | number[]) => {
     setAgeArr(newValue as number[]);
   }
    return(<div style={{width:"50vw"}}>

  <Accordion defaultExpanded  onChange={handleChange('panel1')}>
          <AccordionSummary aria-controls="panel1d-content" id="panel1d-header">
            <Typography  component="span"  variant="body2">Country</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
            <Grid container size={12}>
 {countries.map((country)=>(
          <Grid size={{xs:12,sm:6,md:4,lg:4,xl:3}}><FormControlLabel 
          control={
              <Checkbox onChange={()=>handleCountryChangeCheckBox(String(country))} name={String(country)} />
            }
            label={<Typography variant="body2">
             {String(country).charAt(0).toUpperCase()+String(country).slice(1).toLowerCase()}</Typography>}
          />
          </Grid>
        ))}
 </Grid>
          </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion  defaultExpanded onChange={handleChange('panel2')}>
          <AccordionSummary aria-controls="panel2d-content" id="panel2d-header">
            <Typography component="span" variant="body2">Religion</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <Grid container size={12}>
            {religions.map((religion:String,index:number,)=>{
             
              return( <Grid size={{xs:12,md:6,lg:4,xl:3}}><FormControlLabel sx={{display:"flex",flexShrink:1}}
                control={
                    <Checkbox onChange={()=>handleReligionChangeCheckBox(String(religion))} name={String(religion)} />
                  }
                  label={
                    <Typography variant="body2">
                    {String(religion).charAt(0).toUpperCase()+String(religion).slice(1).toLowerCase()}</Typography>}
                /></Grid>)
            })}</Grid>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion  defaultExpanded onChange={handleChange('panel3')}>
          <AccordionSummary aria-controls="panel3d-content" id="panel3d-header">
            <Typography component="span"  variant="body2">Profession</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <Grid container size={12}> 
            {professions.map(profession=>(
         <Grid size={{xs:12,md:6,lg:4,xl:3}}> <FormControlLabel 
          control={
              <Checkbox onChange={()=>handleProfessionChangeCheckBox(String(profession))} name={String(profession)} />
            }
            label={<Typography variant="body2">{String(profession).charAt(0).toUpperCase()+String(profession).slice(1).toLowerCase()}
            </Typography>}
          /></Grid>
        ))}</Grid>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion  defaultExpanded onChange={handleChange('panel4')}>
          <AccordionSummary aria-controls="panel4d-content" id="panel4d-header">
            <Typography component="span"  variant="body2">Age</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
            <Slider
        track="inverted"
         valueLabelDisplay="auto"
        aria-labelledby="track-inverted-range-slider"
        getAriaValueText={valuetext}
        defaultValue={[20, 50]}
        marks={marks}
        onChange={onChangeAge}
        min={20}
        max={50}
      />
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion  defaultExpanded onChange={handleChange('panel5')}>
          <AccordionSummary aria-controls="panel5d-content" id="panel5d-header">
            <Typography  variant="body2" component="span">Caste</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <Grid container size={12}>
            {castes.map(caste=>(
          <Grid  size={{xs:6,md:6,lg:4,xl:3}}><FormControlLabel 
          control={
              <Checkbox onChange={()=>handleCasteChangeCheckBox(String(caste))} name={String(caste)} />
            }
            label={<Typography variant="body2">{String(caste).charAt(0).toUpperCase()+String(caste).slice(1).toLowerCase()}
            </Typography>}
          /></Grid>
        ))}
        </Grid>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <div style={{padding:"2em"}} >
          <Button variant="contained" onClick={onClickFilterResult} startIcon={<FilterListIcon/>}>Filter Result</Button>
          </div>
      </div>);

}

export default SideMenuBar;