import type { Country } from "../../types/SelectedCountry";

const countries :Country[] = [
    {
        id:1,
        name:"UK",
        checked:false
    },
    {
        id:2,
        name:"Australia",
        checked:false
    },{
         id:3,
        name:"Sri Lanka",
        checked:false
    },{
        id:4,
       name:"Canada",
       checked:false
   },{
        id:5,
        name:"Germany",
        checked:false
    }
]

export  default countries;