import type { Religion } from "../Registration/types/Religion";

export const religions:Religion[] = [

    {
        id:1,
        name:"Hindu Gobiyar"
    },
    {
        id:1,
        name:"Christian"
    },
    {
        id:1,
        name:"Hindu vellalar"
    },
    {
        id:1,
        name:"Muslim "
    },

]