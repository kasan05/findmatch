import { Badge, Box, Button, Card, CardContent,Container, createTheme, Grid, Stack, SwipeableDrawer, Tooltip, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import "./Search.css";
import FeaturedService from "../Featuredservice/Featuredservice";
import Filter from "../Filter/Filter";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useAuth } from "../../context/AppAuthContext";
import CloseIcon from '@mui/icons-material/Close';
import { loadPersonnelData } from "../../store/matchmakerSlice";
import FilterListIcon from '@mui/icons-material/FilterList';
import FilterAltOffIcon from '@mui/icons-material/FilterAltOff';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import type { FilterInput } from "../../types/FilterInput";
const theme = createTheme({

    components:{
        MuiListItemIcon:{
            styleOverrides:{
                root:({theme})=>({
                    [theme.breakpoints.down('md')]:{
                        paddingLeft:"3rem",
                    },
                    [theme.breakpoints.up('md')]:{
                            fontSize:"2rem"
                    }
                })
            }
        },
        MuiButton:{
            styleOverrides:{
                root:({theme})=>({
                    [theme.breakpoints.down('md')]:{
                       fontSize:"0.6rem",
                       width:"6rem",
                       marginLeft:"5rem !important"
                    },
                    [theme.breakpoints.up('md')]:{
                            fontSize:"1rem"
                    }
                })
            }
        }
    }
})
const Search = ()=>{
    const [rowPerpage,setRowPerpage] = useState(0);
    const [page,setPage] = useState(0);
    const[hideFilter,setHideFilter]=useState<boolean>(false);
    const dispatch = useAppDispatch();
    const [dOpen, setDOpen] = useState(false);
    const castes =  useAppSelector(state=>state.matchMaker.castes);
    const countries = useAppSelector(state=>state.matchMaker.countries);
    const maritalStatuses = useAppSelector(state=>state.matchMaker.maritalStatuses);
    const genders = useAppSelector(state=>state.matchMaker.genders);
    const professions = useAppSelector(state=>state.matchMaker.professions);
    const religions = useAppSelector(state=>state.matchMaker.religions);
    const [countryFilterData,setCountryFilterData] = useState<Array<string>>([]);
    const [professionFilterData,setProfessionFilterData] = useState<Array<string>>([]);
    const [ageArr,setAgeArr] = useState<string>("");

   const passFilterData=(filterData:FilterInput)=>{
    const c:Array<string> = filterData.selectedCountriesTemp;
        if(c){
            setCountryFilterData(c);
        }
    const pr:Array<string> = filterData.selectedProfessionsTemp;
        if(pr){
            setProfessionFilterData(pr);
        }
    const ag:Array<number> = filterData.ageArr;
        if(ag && ag.length==2){
            setAgeArr("Age Between:"+ag[0]+" and "+ag[1])
        }

   }
    const closeSideBar =(open:boolean)=>{
        console.log("dsdsdsdsdsdsdsdsdsdsds")
        setDOpen(!dOpen);
        setHideFilter(!hideFilter);
    }
    const passPage = (page:number)=>{
        setPage(page);
    }
    const toggleDrawer = (dOpen: boolean) => () => {
        if(!dOpen){
            setHideFilter(true);
        }
        setDOpen(dOpen);
      };
    const hideFilterFunc = ()=>{
       setDOpen(!dOpen);
       setHideFilter(!hideFilter);
    }
    const passRowPerPage = (rPerPage:number)=>{
        setRowPerpage(rPerPage);
    }
    const {isAutheticated,user} =  useAuth();
    useEffect(()=>{

        dispatch(loadPersonnelData());
        console.log("from search.........");
        console.log(isAutheticated);
       
        console.log("from search");
      
      },[dispatch])
    return(<Container sx={{padding:0}}>    
        <SwipeableDrawer 
                anchor="left"
                transitionDuration={250}
                open={dOpen}
                sx={{overflow:"hidden",width:"100%"}}
                onClose={toggleDrawer(false)}
                onOpen={toggleDrawer(true)}
                disableSwipeToOpen={false}
                keepMounted>
                <Box>
                    <Stack  sx={{background:"#ADD8E6"}} direction={"row"}  justifyContent={"center"} alignContent={"center"}>
                    <Typography sx={{padding:2}} variant="h6">Filters</Typography>
                    <Button sx={{marginLeft:"auto",color:"black"}}  onClick={toggleDrawer(false)}><CloseIcon/></Button>
                    </Stack>
                <Filter countries={countries} castes={castes} maritalStatuses={maritalStatuses}
                genders={genders} religions={religions} professions={professions} page={page} rowPerpage={rowPerpage}
                closeSideBar={closeSideBar} passFilterData={passFilterData}/>
                </Box>
        </SwipeableDrawer>
        <Stack direction={"column"} sx={{padding:2}} spacing={2}>
            <Card elevation={0}>
                <CardContent>
                <Grid container size={{xs:12,sm:6,md:4,lg:3}} gap={1} justifyContent={"left"} alignItems={"center"} >
                <Grid><Tooltip title={countryFilterData?.join(",")}><Button   sx={{color:"black"}} startIcon={
                     <Badge badgeContent={countryFilterData?.length} color="primary"><FilterListIcon/></Badge>
                    } onClick={hideFilterFunc}> Countries</Button></Tooltip>
                    </Grid>
                <Grid><Button  sx={{color:"black"}} startIcon={<FilterListIcon/>}> Religion</Button></Grid>
                <Grid> 
                <Tooltip title={professionFilterData?.join(",")}>
                    <Button  sx={{color:"black"}} startIcon={<Badge badgeContent={professionFilterData?.length} color="primary"><FilterListIcon/></Badge>}> Profession</Button>
                    </Tooltip>
                    </Grid>
                <Grid> 
                <Tooltip title={ageArr}>
                    <Button  sx={{color:"black"}} startIcon={ageArr && ageArr!==""?<Badge badgeContent={1} color="primary">
                    <FilterListIcon/>
                    </Badge>:(
                    <FilterListIcon/>
                    )}>Age</Button></Tooltip></Grid>
                <Grid><Button  sx={{color:"black"}} startIcon={<FilterListIcon/>}> Caste</Button></Grid>
                <Grid>
                <Button  sx={{color:"black"}} startIcon={(professionFilterData?.length>0 || countryFilterData?.length>0) ?<FilterAltIcon/>:<FilterAltOffIcon/>}>Clear Filters</Button></Grid>
                <Grid>
                    <Button  sx={{color:"black"}}onClick={hideFilterFunc} 
                            startIcon={<VisibilityOffIcon/>}>
                                {hideFilter?"Show Filter":"Hide Filter"}
                    </Button>  
                </Grid>
                </Grid>
                </CardContent>
            </Card>
        {/* <Button sx={{width:"10rem"}} onClick={hideFilterFunc} 
                 startIcon={<VisibilityOffIcon/>}>
            <Typography variant="h5" sx={{fontSize:{xs:'0.8rem',md:'0.8rem'}}}>
                {hideFilter?"Show Filter":"Hide Filter"}
            </Typography></Button>     */}
        </Stack>           
        <FeaturedService  passRowPerPage={passRowPerPage}
    passPage={passPage}/>
    </Container>);
}

export default Search;