import { Checkbox, ListItemIcon, ListItemText, MenuItem, MenuList, Paper } from "@mui/material";
import React from "react";

type CustomListProps = {
    items: readonly number[];
    checked: readonly number[];
    handleToggle: (value: number) => () => void;
  };

export const CustomList = React.forwardRef(function CustomList(
    props: CustomListProps,
    ref: React.Ref<HTMLDivElement & { focus: () => void }>,
  ) {
    const { items, checked, handleToggle } = props;
  
    return (
      <Paper sx={{ width: 200, height: 230, overflow: 'auto' }}>
        <MenuList dense component="div" role="list" ref={ref}>
          {items.map((value: number) => {
            const labelId = `transfer-list-item-${value}-label`;
  
            return (
              <MenuItem
                component="div"
                key={value}
                role="listitem"
                onClick={handleToggle(value)}
              >
                <ListItemIcon>
                  <Checkbox
                    checked={checked.includes(value)}
                    tabIndex={-1}
                    disableRipple
                    slotProps={{
                      input: { 'aria-labelledby': labelId },
                    }}
                  />
                </ListItemIcon>
                <ListItemText id={labelId} primary={`List item ${value + 1}`} />
              </MenuItem>
            );
          })}
        </MenuList>
      </Paper>
    );
  });