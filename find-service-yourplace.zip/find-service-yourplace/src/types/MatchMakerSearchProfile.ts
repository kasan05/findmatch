export type  MatchMakerSearchProfile ={
    id:string,
    name:string
    profession:string
    age:number
    country:string
    caste:string
    friendRequestStatus:string
    gender:string
}   
