import type { FilterInput } from "./FilterInput"

export type Page = {
    limit:number,
    signal?:AbortSignal,
    offset:number,
    filterInput:FilterInput
}