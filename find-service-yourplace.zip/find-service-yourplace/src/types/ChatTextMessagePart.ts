export type ChatTextMessagePart ={
    type:string,
    text:string,
    state:string
}