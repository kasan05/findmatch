export type FilterInput = {
    selectedCountriesTemp:Array<string>,
    selectedCastesTemp:Array<string>,
    selectedProfessionsTemp:Array<string>,
    selectedReligionsTemp:Array<string>,
    ageArr:Array<number>
}
