import type { ChatTextMessagePart } from "./ChatTextMessagePart"
import type { ChatUserDTO } from "./ChatUserDTO"

export type AppChatMessage= {
    id:string,
    conversationId:string,
    role:string,
    status:string,
    createdAt:string,
    author:ChatUserDTO,
    parts:Array<ChatTextMessagePart>
}