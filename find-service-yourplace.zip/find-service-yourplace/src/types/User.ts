export default interface User {
     id:string,
      token:string,
       name:string,
       userStatus:string
}