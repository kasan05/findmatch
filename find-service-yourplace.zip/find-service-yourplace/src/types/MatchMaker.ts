export type MatchMaker = {
    caste:string,
    gender:string,
    maritalStatus:string,
    country:string,
    id:string,
    multipartFiles:Array<any>,
    profession:string,
    religion:string
    name:string
}