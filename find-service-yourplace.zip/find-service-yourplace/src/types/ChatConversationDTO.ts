import type { ChatUserDTO } from "./ChatUserDTO"

export type ChatConversationDTO = {
    id:string,
    title:string,
    subtitle:string,
    participants:Array<ChatUserDTO>,
    readState:string,
    unreadCount:number,
    lastMessageAt:string
}