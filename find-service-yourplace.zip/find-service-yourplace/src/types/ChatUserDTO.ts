export type ChatUserDTO = {
    id:string,
    displayName:string,
    isOnline:boolean
}
