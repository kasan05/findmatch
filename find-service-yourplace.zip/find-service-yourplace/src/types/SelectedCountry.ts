export type Country = {
    id:number,
    name:string,
    checked:boolean
}