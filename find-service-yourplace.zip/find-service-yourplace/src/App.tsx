import './App.css'
import '@fontsource/roboto';
import Navbar from './components/Navbar/Navbar';
import theme from './assets/theme'
import { ThemeProvider } from '@emotion/react';
import {  createBrowserRouter, Outlet, redirect, RouterProvider } from 'react-router-dom';
import { updateAuthState } from './store/brokerSlice';
import { useAppDispatch } from './store/hooks';
import { lazy, Suspense, useEffect, useRef } from 'react';
import Footer from './components/footer/Footer';
import { Box} from '@mui/material';


function App() {
  const abortControllerRef = useRef<boolean>(false);
  const dispatch = useAppDispatch(); 
  // const memoFunc = useCallback(()=>{
  //   console.log("useCallback calling")
  //   return verifySessionOrRedirect();
  // },[])

   async function verifySessionOrRedirect() {

    // try {
    //   const response = await fetch('http://findmatch-latest-alb-64547718.ap-south-1.elb.amazonaws.com/user/profile',{
    //     method:"GET",
    //     headers:{"Content-Type":"application/json"},
    //     credentials: 'include'
    // });
      
    //   if (!response.ok) {
    //     throw redirect("/login");
    //   }
      
    //   const res = await response.json();
    //   dispatch(updateAuthState(res));
    //   console.log(res);
    //   return res;
    // } catch (error) {
     
    //   throw redirect("/login");
    // }
  } 

const Parent =()=>{  
  return(
    <>
   
    <Box sx={{
     overflow: 'hidden',
       display: 'flex',
       flexDirection: 'column',
       minHeight: '100vh',
      
    }}>
       <Navbar />
          <Box sx={{flex:1,mt:5}}>
                <Outlet/>
          </Box>
          <Footer/>
    </Box>
    </>
  )
}
const withSuspense = (Component:React.ComponentType)=>(
  <Suspense>
    <Component/>
  </Suspense>
)
const Home = lazy(()=>import("./components/Hero/Hero"));
const MatchMakerProfile = lazy(()=>import("./components/profile/MatchMaker/MatchMakerProfile"));
const Search = lazy(()=>import("./components/search/Search"));
const Login = lazy(()=>import("./components/login/Login"));
const BrokerRegistration = lazy(()=>import("./components/Registration/Broker/BrokerRegistration"));
const MatchMakerRegistration = lazy(()=>import("./components/Registration/matchmaker/MatchMakerRegistration"));
const ChatScreen = lazy(()=>import("./components/chat/ChatScreen"));
const FriendChatScreen = lazy(()=>import("./components/chat/FriendChatScreen"));
const Friendrequest = lazy(()=>import("./components/Friends/FriendRequest"));
const FriendProfile = lazy(()=>import("./components/profile/FriendProfile"));
const AdditionalDetailMatchMaker = lazy(()=>import("./components/AditionalDetails/AdditionalDetailMatchMaker"));


  const router = createBrowserRouter([
   
   {
    element: <Parent/>,
    children: [
      {
        path:"/",
        element: withSuspense(Home)
      },
      {
        path:"/home",
        element: withSuspense(Home)
      },
      {
        path:"/broker/register",
        element: withSuspense(BrokerRegistration)
      },
      {
        path:"/match-maker/register",
        element: withSuspense(MatchMakerRegistration)
      },
      {
        path:"/login",
        element: withSuspense(Login)
      },
      {
        loader: async () => {
           await verifySessionOrRedirect();
        },children:[{
          path:"/search",
          element: withSuspense(Search)
        }, {
          path:"/inbox",
          element: withSuspense(ChatScreen)
        },{
          path:"/friends/request",
          element: withSuspense(Friendrequest)
        },{
          path:"/match-maker/profile",
          element: withSuspense(MatchMakerProfile)
        },{
          path:"/match-maker/profile/friend",
          element: withSuspense(FriendProfile)
        },{
          path:"/chat/friend",
          element: withSuspense(FriendChatScreen)
        }]
      
      },
      {
        path:"/match-maker/additional-details",
        element:withSuspense(AdditionalDetailMatchMaker)
      },{
        path:"*",
        element:withSuspense(Login)
      }
    ]
   }
  
  ]);
  return (
    <>
    <ThemeProvider theme={theme}>
       <div className='rmy'>
        <RouterProvider router={router}/>
      </div>
    </ThemeProvider>
    </>
  )
}

export default App
