declare module "*.css";
declare module "*.png";
declare module "@fontsource/*" {}
declare module "@fontsource-variable/*" {}