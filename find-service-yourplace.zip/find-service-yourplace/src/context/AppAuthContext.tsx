import {createContext, useContext, useMemo, type ReactNode} from "react";
import { useAppSelector } from "../store/hooks";
import type User from "../types/User";

interface AuthContextType {
    user :User | null,
    isAutheticated:boolean
}
const AuthContext = createContext<AuthContextType| null>(null);

export function AuthProvider({children}:{children:ReactNode}){
    const user:User = useAppSelector(state=>state.broker.user);
    const isAutheticated = useAppSelector(state=>state.broker.isAutheticated);
    const contextValue = useMemo(()=>{
        return {
            user:user,
            isAutheticated:isAutheticated
        }
    },[user,isAutheticated])
    return <AuthContext.Provider value={contextValue}>
        {children}
        </AuthContext.Provider>;
}
export const useAuth = ()=>{
    const context = useContext(AuthContext);
    if(!context){
        throw new Error("useAuth must be used within an AuthProvider")
    }
    return context;
}